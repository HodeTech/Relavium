import {
  CATALOG_METADATA_ORIGINS,
  EXECUTION_MODES,
  FS_SCOPE_TIERS,
  MEDIA_MODALITIES,
  MEDIA_SCOPE_KINDS,
  RunStatusSchema,
  SessionStatusSchema,
  type CatalogMetadataOrigin,
  type ExecutionMode,
  type FsScopeTier,
  type MediaModality,
  type MediaScopeKind,
  type MediaSurface,
  type ModelCatalogSource,
  type ProviderKind,
  type RunStatus,
  type SessionStatus,
} from '@relavium/shared';
import { desc, sql } from 'drizzle-orm';
import { check, index, integer, sqliteTable, text, uniqueIndex } from 'drizzle-orm/sqlite-core';

/**
 * The Phase-1 local table set, modeling the canonical DDL in
 * [database-schema.md](../../../docs/reference/shared-core/database-schema.md) as a Drizzle
 * SQLite schema. **One schema, two dialects** ([ADR-0005](../../../docs/decisions/0005-sqlite-drizzle-local-postgres-cloud.md)):
 * table and column names are kept dialect-identical so the Phase-2 Postgres port is a
 * driver/dialect change, not a rewrite.
 *
 * Conventions enforced here (from database-schema.md §conventions):
 * - **UUID** primary keys are `TEXT`, generated in application code — never a DB default.
 * - **JSON** documents are stored as `TEXT` (a JSON string; queried with `json_extract`).
 *   Kept as `string` at this layer; typed accessors are a consumer concern (Phase 1).
 * - **Timestamps** are `INTEGER` Unix **epoch-milliseconds** (timezone handled in app code).
 * - **Money** is `INTEGER` **micro-cents** (1 micro-cent = 1e-8 USD).
 * - **Enums** are `TEXT` + a `CHECK (... IN (...))` constraint — never a native enum type.
 *   The `runs.status` and `runs.execution_mode` value sets are imported from
 *   `@relavium/shared` so the persisted CHECK can never drift from the logical contract.
 * - **Booleans** are `INTEGER` 0/1 (Drizzle `mode: 'boolean'`).
 * - **Soft delete** is a nullable `deleted_at` epoch-ms cursor with partial unique/active
 *   indexes (`WHERE deleted_at IS NULL`).
 *
 * No engine wiring lives here — this is schema/migrations only (Phase 0 workstream 0.I);
 * the FK-cascade and index choices come straight from the reference DDL.
 */

// --- Column-convention helpers (each returns a fresh builder per call) ---

/** UUID stored as TEXT, generated in application code (no DB default). */
const uuidPk = () => text('id').primaryKey();
/** Epoch-millisecond timestamp stored as INTEGER. */
const epochMs = (name: string) => integer(name);
/** Integer micro-cents (money), defaulting to 0. */
const microcents = (name: string) => integer(name).notNull().default(0);
/** A non-negative token counter, defaulting to 0. */
const tokenCount = (name: string) => integer(name).notNull().default(0);
/** A JSON document stored as a TEXT string. */
const jsonText = (name: string) => text(name);

/** An INTEGER bool (0/1) flag with a 0/1 default, matching the canonical DDL exactly
 * (Drizzle `mode: 'boolean'` reads/writes JS booleans over the 0/1 storage). */
const boolFlag = (name: string, def: boolean) =>
  integer(name, { mode: 'boolean' })
    .notNull()
    .default(def ? sql`1` : sql`0`);

/** A `CHECK (col IN ('a','b',...))` from a closed value list. Values come from our own
 * `as const` constants (never user input); the single-quote escape is belt-and-suspenders
 * so the helper is safe even if a value with a quote is ever passed. */
const inList = (values: readonly string[]) =>
  sql.raw(values.map((v) => `'${v.replaceAll("'", "''")}'`).join(', '));

// --- 1. llm_providers (no FKs) ---

export const llmProviders = sqliteTable(
  'llm_providers',
  {
    id: uuidPk(),
    name: text('name').notNull(),
    displayName: text('display_name').notNull(),
    baseUrl: text('base_url').notNull(),
    // keychain `account` identifier — NEVER the key itself (ADR-0006).
    apiKeyKeychainRef: text('api_key_keychain_ref'),
    defaultHeaders: jsonText('default_headers').notNull().default('{}'),
    // ADR-0065 §5: the provider's protocol `kind` (a custom OpenAI-compatible `base_url` reuses it) + a pricing
    // page `pricing_reference_url` (a UX pointer for user-supplied pricing, S10). Both NULLABLE — populated for
    // uniformity, load-bearing only for a custom provider; validated against `PROVIDER_KINDS` at the store read
    // boundary (no DB CHECK — SQLite `ALTER ADD` limitation), mirroring `model_catalog.source`.
    kind: text('kind').$type<ProviderKind>(),
    pricingReferenceUrl: text('pricing_reference_url'),
    isActive: boolFlag('is_active', true),
    deletedAt: epochMs('deleted_at'),
    createdAt: epochMs('created_at').notNull(),
    updatedAt: epochMs('updated_at').notNull(),
  },
  (t) => [
    uniqueIndex('idx_llm_providers_name')
      .on(t.name)
      .where(sql`${t.deletedAt} is null`),
  ],
);

// --- 2. model_catalog (-> llm_providers) ---

export const modelCatalog = sqliteTable(
  'model_catalog',
  {
    id: uuidPk(),
    providerId: text('provider_id')
      .notNull()
      .references(() => llmProviders.id),
    modelId: text('model_id').notNull(),
    displayName: text('display_name').notNull(),
    contextWindowTokens: integer('context_window_tokens').notNull(),
    maxOutputTokens: integer('max_output_tokens').notNull(),
    inputCostPerMtokMicrocents: microcents('input_cost_per_mtok_microcents'),
    outputCostPerMtokMicrocents: microcents('output_cost_per_mtok_microcents'),
    cachedInputCostPerMtokMicrocents: microcents('cached_input_cost_per_mtok_microcents'),
    /**
     * Did the USER actually state a cache-read rate (ADR-0071 §10)?
     *
     * The money column is `NOT NULL DEFAULT 0`, so it cannot tell "the user typed `--cached 0`" — a genuinely free
     * cache on a self-hosted endpoint — apart from "the user never mentioned cache reads". Reading a stored `0` as
     * "free" bills a whole class of tokens at nothing; reading it as "unset" discards an explicit instruction. One
     * money column cannot hold both meanings, so the FACT of the statement gets its own flag.
     *
     * `0` ⇒ not stated: the cache rate is derived at read time from the catalog's cache DISCOUNT applied to the
     * user's own input rate (never the catalog's absolute rate — a user who negotiated $0.10/MTok on a model whose
     * catalog cache rate is $0.50 would otherwise pay 5× MORE for a cache hit than for a miss).
     */
    cachedInputStated: boolFlag('cached_input_stated', false),
    /**
     * Did the USER state the token rates (migration 0016, ADR-0089 §4)? The sibling of `cached_input_stated`,
     * for the same reason: `input_/output_cost_per_mtok_microcents` are `NOT NULL DEFAULT 0`, so "never said"
     * and "stated free" are the same bytes. `0` ⇒ a reader inherits the catalog's token rates; `1` ⇒ the
     * numbers above are the user's own, zero included. Needed only since a MEDIA-ONLY `models pricing`
     * invocation became legal — before that, a `source='user'` row always carried stated rates.
     */
    tokenRatesStated: boolFlag('token_rates_stated', false),
    // Per-modality media-OUTPUT rates (1.AF/D17, ADR-0044 §3) — integer µ¢ per billed unit (per image,
    // per audio-second, per video-second). NULLABLE, and null means UNPRICED, not free: since ADR-0089 §4 a
    // missing rate is reported as an unpriced modality and REFUSED under a strict cost cap (it used to
    // degrade to 0, which is the `CR-55` defect — a price the governor cannot tell from "nothing to charge")
    // (H4). The projection of `ModelPricing.mediaOutputRates`; no shipped model carries one yet.
    mediaImageCostMicrocents: integer('media_image_cost_microcents'),
    mediaAudioCostMicrocents: integer('media_audio_cost_microcents'),
    mediaVideoCostMicrocents: integer('media_video_cost_microcents'),
    // Inline-vs-generative media-output routing (1.AG/ADR-0045 §1): a 'generative' model routes an agent
    // node to generateMedia() (separate-endpoint sync / async-LRO); 'chat' (default) uses the normal turn
    // with output_modalities. Projects onto CapabilityFlags.media.surface; data-driven (no hardcoded ids).
    // Value-set enforced by the `MediaSurface` type + the closed `MEDIA_SURFACES` set (and, at the seam,
    // the optional `CapabilityFlags.media.surface = z.enum(MEDIA_SURFACES)`). A DB CHECK is deferred:
    // SQLite does not support adding a CHECK via `ALTER TABLE ADD COLUMN` — enforcing it would need a full
    // table-rebuild migration (the sibling enum checks live in the initial CREATE; this column is an ALTER ADD).
    mediaSurface: text('media_surface').$type<MediaSurface>().notNull().default('chat'),
    supportsToolCalling: boolFlag('supports_tool_calling', false),
    supportsVision: boolFlag('supports_vision', false),
    supportsStreaming: boolFlag('supports_streaming', true),
    supportsJsonMode: boolFlag('supports_json_mode', false),
    capabilities: jsonText('capabilities').notNull().default('{}'),
    deprecationDate: epochMs('deprecation_date'),
    // Live-discovery cache provenance (2.5.G/ADR-0064 §4): `'static'` (a hardcoded capability/media seed — the
    // default the media-routing `upsert` path writes), `'live'` (discovered via the seam's `listModels` — the
    // bulk refresh writes it), `'user'` (user-supplied pricing, ADR-0065). A text column with a CONSTANT default
    // is legal on `ALTER TABLE ADD` (the table ships EMPTY so existing rows are moot). Like `media_surface`,
    // SQLite `ALTER ADD` carries no CHECK, so the closed `MODEL_CATALOG_SOURCES` set is validated at the store
    // read boundary (`coerceModelCatalogSource`, model-catalog-store.ts) — a tampered value degrades to `'static'`.
    source: text('source').$type<ModelCatalogSource>().notNull().default('static'),
    // The epoch-ms a live refresh last wrote this row (ADR-0064 §5 TTL freshness); NULLABLE — NULL for a
    // static/user row or a never-refreshed row. Backs `providerRefreshedAt` (the max over a provider's active
    // `source='live'` rows). Additive nullable ALTER ADD, like the `media_*_cost_microcents` columns (0003).
    lastRefreshedAt: epochMs('last_refreshed_at'),
    // Per-model PICKER visibility (ADR-0072 point 4) — a HARD filter ABOVE ADR-0064 §6's "dim, never hide"
    // availability rule, and ORTHOGONAL to is_active: a reachable-but-hidden model is `is_active=1, visible=0`.
    // The `/settings > /models` toggle writes it; every write path that rewrites a row must PRESERVE it by
    // read-modify-write, so a routine availability refresh never silently un-hides a model the user hid. Additive
    // `ALTER ADD` with a constant `1` default (the table's rows are all visible until the user hides one).
    visible: boolFlag('visible', true),
    isActive: boolFlag('is_active', true),
    deletedAt: epochMs('deleted_at'),
    createdAt: epochMs('created_at').notNull(),
    updatedAt: epochMs('updated_at').notNull(),
  },
  (t) => [
    uniqueIndex('idx_model_catalog_provider_model')
      .on(t.providerId, t.modelId)
      .where(sql`${t.deletedAt} is null`),
    index('idx_model_catalog_provider').on(t.providerId),
    index('idx_model_catalog_active')
      .on(t.isActive)
      .where(sql`${t.deletedAt} is null`),
  ],
);

// --- 3. agents (-> model_catalog) ---

export const agents = sqliteTable(
  'agents',
  {
    id: uuidPk(),
    name: text('name').notNull(),
    slug: text('slug').notNull(),
    description: text('description'),
    modelId: text('model_id')
      .notNull()
      .references(() => modelCatalog.id),
    systemPrompt: text('system_prompt').notNull().default(''),
    tools: jsonText('tools').notNull().default('[]'),
    config: jsonText('config').notNull().default('{}'),
    inputSchema: jsonText('input_schema'),
    outputSchema: jsonText('output_schema'),
    tags: jsonText('tags').notNull().default('[]'),
    sourcePath: text('source_path'),
    isActive: boolFlag('is_active', true),
    deletedAt: epochMs('deleted_at'),
    createdAt: epochMs('created_at').notNull(),
    updatedAt: epochMs('updated_at').notNull(),
  },
  (t) => [
    uniqueIndex('idx_agents_slug')
      .on(t.slug)
      .where(sql`${t.deletedAt} is null`),
    index('idx_agents_model').on(t.modelId),
    index('idx_agents_active')
      .on(t.isActive, desc(t.createdAt))
      .where(sql`${t.deletedAt} is null`),
  ],
);

// --- 4. workflows (no FKs) ---

export const workflows = sqliteTable(
  'workflows',
  {
    id: uuidPk(),
    name: text('name').notNull(),
    slug: text('slug').notNull(),
    description: text('description'),
    definition: jsonText('definition').notNull(),
    inputSchema: jsonText('input_schema'),
    tags: jsonText('tags').notNull().default('[]'),
    sourcePath: text('source_path'),
    isActive: boolFlag('is_active', true),
    deletedAt: epochMs('deleted_at'),
    createdAt: epochMs('created_at').notNull(),
    updatedAt: epochMs('updated_at').notNull(),
  },
  (t) => [
    uniqueIndex('idx_workflows_slug')
      .on(t.slug)
      .where(sql`${t.deletedAt} is null`),
    index('idx_workflows_active')
      .on(t.isActive, desc(t.updatedAt))
      .where(sql`${t.deletedAt} is null`),
  ],
);

// --- 5. runs (-> workflows) ---

export const runs = sqliteTable(
  'runs',
  {
    id: uuidPk(),
    workflowId: text('workflow_id')
      .notNull()
      .references(() => workflows.id),
    workflowPath: text('workflow_path'),
    projectRoot: text('project_root'),
    // The frozen graph that actually ran — for replay/resume after the YAML changes.
    workflowDefinitionSnapshot: jsonText('workflow_definition_snapshot').notNull(),
    status: text('status').$type<RunStatus>().notNull().default('pending'),
    executionMode: text('execution_mode').$type<ExecutionMode>().notNull().default('local'),
    // trigger_type carries NO strict CHECK (database-schema.md) — webhook/schedule are
    // Phase-2 values that may legitimately appear; only the default is pinned here.
    triggerType: text('trigger_type').notNull().default('manual'),
    triggerMetadata: jsonText('trigger_metadata').notNull().default('{}'),
    inputJson: jsonText('input_json').notNull().default('{}'),
    outputJson: jsonText('output_json'),
    errorJson: jsonText('error_json'),
    startedAt: epochMs('started_at'),
    completedAt: epochMs('completed_at'),
    totalInputTokens: tokenCount('total_input_tokens'),
    totalOutputTokens: tokenCount('total_output_tokens'),
    totalCostMicrocents: microcents('total_cost_microcents'),
    deletedAt: epochMs('deleted_at'),
    createdAt: epochMs('created_at').notNull(),
    updatedAt: epochMs('updated_at').notNull(),
  },
  (t) => [
    // CHECK value sets imported from @relavium/shared so the persisted enum cannot
    // drift from the logical RunSchema contract.
    check('runs_status_check', sql`${t.status} in (${inList(RunStatusSchema.options)})`),
    check('runs_execution_mode_check', sql`${t.executionMode} in (${inList(EXECUTION_MODES)})`),
    index('idx_runs_workflow').on(t.workflowId, desc(t.createdAt)),
    index('idx_runs_status')
      .on(t.status, desc(t.createdAt))
      .where(sql`${t.deletedAt} is null`),
    index('idx_runs_cost')
      .on(t.workflowId, t.createdAt, t.totalCostMicrocents)
      .where(sql`${t.deletedAt} is null`),
    // Backs the workflow-agnostic recency lists (`listRuns`/`listActiveRuns` + the 2.5.B Home strip): the
    // ORDER BY `(created_at DESC, id DESC)` over the non-deleted set is served straight off this partial index
    // instead of a `USE TEMP B-TREE` filesort, so the Home cold-open stays fast at scale (discharges the §2.I
    // perf follow-up). The `WHERE deleted_at IS NULL` partial matches every read's soft-delete predicate.
    index('idx_runs_created')
      .on(desc(t.createdAt), desc(t.id))
      .where(sql`${t.deletedAt} is null`),
  ],
);

// --- 6. step_executions (-> runs CASCADE, agents, model_catalog) ---

const STEP_STATUSES = ['pending', 'running', 'completed', 'failed', 'skipped'] as const;
type StepStatus = (typeof STEP_STATUSES)[number];

export const stepExecutions = sqliteTable(
  'step_executions',
  {
    id: uuidPk(),
    runId: text('run_id')
      .notNull()
      .references(() => runs.id, { onDelete: 'cascade' }),
    nodeId: text('node_id').notNull(),
    nodeType: text('node_type').notNull(),
    agentId: text('agent_id').references(() => agents.id),
    agentSnapshot: jsonText('agent_snapshot'),
    modelId: text('model_id').references(() => modelCatalog.id),
    attemptNumber: integer('attempt_number').notNull().default(1),
    status: text('status').$type<StepStatus>().notNull().default('pending'),
    inputJson: jsonText('input_json').notNull().default('{}'),
    outputJson: jsonText('output_json'),
    errorJson: jsonText('error_json'),
    startedAt: epochMs('started_at'),
    completedAt: epochMs('completed_at'),
    durationMs: integer('duration_ms'),
    inputTokens: tokenCount('input_tokens'),
    outputTokens: tokenCount('output_tokens'),
    cachedTokens: tokenCount('cached_tokens'),
    costMicrocents: microcents('cost_microcents'),
    createdAt: epochMs('created_at').notNull(),
    updatedAt: epochMs('updated_at').notNull(),
  },
  (t) => [
    check('step_executions_status_check', sql`${t.status} in (${inList(STEP_STATUSES)})`),
    index('idx_step_exec_run').on(t.runId, t.createdAt),
    index('idx_step_exec_run_node').on(t.runId, t.nodeId, t.attemptNumber),
    index('idx_step_exec_agent')
      .on(t.agentId, desc(t.createdAt))
      .where(sql`${t.agentId} is not null`),
    index('idx_step_exec_model')
      .on(t.modelId, desc(t.createdAt))
      .where(sql`${t.modelId} is not null`),
    index('idx_step_exec_cost')
      .on(t.modelId, t.createdAt, t.costMicrocents)
      .where(sql`${t.modelId} is not null`),
  ],
);

// --- 7. messages (-> step_executions CASCADE; run_id denormalized, no FK) ---

export const messages = sqliteTable(
  'messages',
  {
    id: uuidPk(),
    stepExecutionId: text('step_execution_id')
      .notNull()
      .references(() => stepExecutions.id, { onDelete: 'cascade' }),
    // Denormalized for per-run query efficiency; the reference DDL declares no FK here.
    runId: text('run_id').notNull(),
    sequenceNumber: integer('sequence_number').notNull(),
    // role values (system|user|assistant|tool) are documented literals; the reference
    // DDL declares no CHECK on role, so none is added here.
    role: text('role').notNull(),
    content: text('content'),
    contentParts: jsonText('content_parts'),
    toolCalls: jsonText('tool_calls'),
    toolCallId: text('tool_call_id'),
    name: text('name'),
    finishReason: text('finish_reason'),
    createdAt: epochMs('created_at').notNull(),
  },
  (t) => [
    index('idx_messages_step').on(t.stepExecutionId, t.sequenceNumber),
    index('idx_messages_run').on(t.runId, t.createdAt),
  ],
);

// --- 8. run_events (-> runs CASCADE; step_execution_id denormalized, no FK) ---

export const runEvents = sqliteTable(
  'run_events',
  {
    id: uuidPk(),
    runId: text('run_id')
      .notNull()
      .references(() => runs.id, { onDelete: 'cascade' }),
    stepExecutionId: text('step_execution_id'),
    // monotonic per run — used for gap detection on reconnect/resync.
    seq: integer('seq').notNull(),
    eventType: text('event_type').notNull(),
    level: text('level').notNull().default('info'),
    nodeId: text('node_id'),
    payloadJson: jsonText('payload_json').notNull().default('{}'),
    ts: epochMs('ts').notNull(),
  },
  (t) => [
    // UNIQUE: `seq` is monotonic per run, so (run_id, seq) must be unique — this enforces
    // the gap-detection invariant at the DB level (a double-write can't reuse a sequence).
    uniqueIndex('idx_run_events_run_seq').on(t.runId, t.seq),
    index('idx_run_events_step')
      .on(t.stepExecutionId, t.ts)
      .where(sql`${t.stepExecutionId} is not null`),
    index('idx_run_events_run_type').on(t.runId, t.eventType, t.ts),
  ],
);

// --- 9. run_costs (-> runs CASCADE, model_catalog) ---

export const runCosts = sqliteTable(
  'run_costs',
  {
    id: uuidPk(),
    runId: text('run_id')
      .notNull()
      .references(() => runs.id, { onDelete: 'cascade' }),
    nodeId: text('node_id').notNull(),
    modelId: text('model_id').references(() => modelCatalog.id),
    inputTokens: tokenCount('input_tokens'),
    outputTokens: tokenCount('output_tokens'),
    costMicrocents: microcents('cost_microcents'),
    createdAt: epochMs('created_at').notNull(),
  },
  (t) => [index('idx_run_costs_run').on(t.runId)],
);

// --- 10. agent_sessions (-> agents, model_catalog; the agent-first chat session, ADR-0024) ---

export const agentSessions = sqliteTable(
  'agent_sessions',
  {
    id: uuidPk(),
    agentId: text('agent_id').references(() => agents.id),
    agentSlug: text('agent_slug').notNull(),
    agentSnapshot: jsonText('agent_snapshot'),
    title: text('title'),
    modelId: text('model_id').references(() => modelCatalog.id),
    // working_dir / git_ref / fs_scope_tier are denormalized out of context_json for indexing/filtering;
    // context_json remains the authoritative frozen SessionContext.
    workingDir: text('working_dir'),
    gitRef: text('git_ref'),
    fsScopeTier: text('fs_scope_tier').$type<FsScopeTier>().notNull().default('sandboxed'),
    status: text('status').$type<SessionStatus>().notNull().default('active'),
    contextJson: jsonText('context_json').notNull().default('{}'),
    totalInputTokens: tokenCount('total_input_tokens'),
    totalOutputTokens: tokenCount('total_output_tokens'),
    totalCostMicrocents: microcents('total_cost_microcents'),
    // ADR-0074 §1/§4 — money a provider MAY already have billed for an attempt that returned no trustworthy
    // usage. Deliberately a SEPARATE column from `total_cost_microcents`, never folded into it: this is an
    // ESTIMATE, and mixing it in would present an upper bound as an invoice and break ADR-0070's
    // `SUM(session_costs.cost_microcents) == total_cost_microcents`. It consumes cap capacity on resume without
    // ever inflating a reported cost. Single-writer, like its realized sibling.
    totalConservativeMicrocents: microcents('total_conservative_microcents'),
    exportedWorkflowPath: text('exported_workflow_path'),
    deletedAt: epochMs('deleted_at'),
    createdAt: epochMs('created_at').notNull(),
    updatedAt: epochMs('updated_at').notNull(),
  },
  (t) => [
    // CHECK value sets imported from @relavium/shared so the persisted enum cannot drift from the
    // logical contract: the shared FS_SCOPE_TIERS list and the SessionStatus contract (session.ts).
    check(
      'agent_sessions_fs_scope_tier_check',
      sql`${t.fsScopeTier} in (${inList(FS_SCOPE_TIERS)})`,
    ),
    check(
      'agent_sessions_status_check',
      sql`${t.status} in (${inList(SessionStatusSchema.options)})`,
    ),
    index('idx_agent_sessions_status')
      .on(t.status, desc(t.updatedAt))
      .where(sql`${t.deletedAt} is null`),
    index('idx_agent_sessions_agent')
      .on(t.agentId, desc(t.createdAt))
      .where(sql`${t.agentId} is not null`),
    // Backs `listSessions` + the 2.5.B Home "recent sessions" strip: the ORDER BY `(updated_at DESC, id DESC)`
    // over the non-deleted set is served off this partial index rather than a filesort (the session counterpart
    // of `idx_runs_created`; §2.I perf discharge). `WHERE deleted_at IS NULL` matches the read's soft-delete filter.
    index('idx_agent_sessions_updated')
      .on(desc(t.updatedAt), desc(t.id))
      .where(sql`${t.deletedAt} is null`),
  ],
);

// --- 11. session_messages (-> agent_sessions CASCADE, model_catalog; append-only transcript) ---

export const sessionMessages = sqliteTable(
  'session_messages',
  {
    id: uuidPk(),
    sessionId: text('session_id')
      .notNull()
      .references(() => agentSessions.id, { onDelete: 'cascade' }),
    sequenceNumber: integer('sequence_number').notNull(),
    // role values (system|user|assistant|tool) are documented literals; the reference DDL declares no
    // CHECK on role (mirrors the run `messages` table), so none is added — the SessionMessageSchema
    // (@relavium/shared) enforces the closed role set at the mapper boundary.
    role: text('role').notNull(),
    content: text('content'),
    // The canonical durable transcript: SessionMessage.content (DurableContentPart[]) is stored here as
    // JSON (database-schema.md §"Mapping SessionMessage to the row"). The other scalar columns below are
    // optional denormalized metadata (NULL when the durable parts array is the sole source of a row).
    contentParts: jsonText('content_parts'),
    toolCalls: jsonText('tool_calls'),
    toolCallId: text('tool_call_id'),
    name: text('name'),
    finishReason: text('finish_reason'),
    // The model that produced an assistant turn (fallback-aware); NULL for non-assistant rows.
    modelId: text('model_id').references(() => modelCatalog.id),
    // NOTE (ADR-0070 §5): the per-message `input_tokens` / `output_tokens` / `cost_microcents` columns were DROPPED.
    // They were never written (the persister never passed a meta payload, so every row shipped 0), never read back,
    // and — decisively — a per-message cost column is STRUCTURALLY incapable of holding the truth for a turn whose
    // tool loop billed two models. Money attribution lives in `session_costs`. `model_id` STAYS: it is written
    // (ADR-0059) and remains the per-message "which model wrote this reply" label.
    // Present ONLY on a compaction/trim boundary marker row (role='system', ADR-0062): the durable
    // sequence_number THROUGH which older messages are superseded. NULL on every normal transcript row.
    // Additive nullable column — an older reader that lacks it reads the marker as an inert system row.
    compactionDroppedThroughSequence: integer('compaction_dropped_through_sequence'),
    createdAt: epochMs('created_at').notNull(),
  },
  (t) => [
    // UNIQUE: sequence_number is monotonic per session (append-only), so (session_id, sequence_number)
    // must be unique — enforcing the gap-free transcript invariant at the DB level (no double-write).
    uniqueIndex('idx_session_messages_seq').on(t.sessionId, t.sequenceNumber),
    index('idx_session_messages_session').on(t.sessionId, t.createdAt),
  ],
);

// --- 11b. session_costs (per-(session, model) money attribution, ADR-0070) ---
// The durable per-model spend of a chat session. It exists because a `session_messages` row holds exactly ONE
// `model_id`, and a single turn can bill TWO models: the tool loop makes a fresh fallback-chain call per iteration,
// so iteration 1 can succeed on model A and iteration 2 fail over to B. A per-message cost column cannot represent
// that turn without lying — which is why `session_messages`' own token/cost columns were dropped (ADR-0070 §5).
//
// THE INVARIANT (ADR-0070 §3): SUM(session_costs.cost_microcents) == agent_sessions.total_cost_microcents, for every
// session. It holds because both sides are fed by the SAME `cost:updated` event, with the same arithmetic, in the
// SAME transaction, from the single emitter — including errored turns, aborted turns, and compaction spend.
export const sessionCosts = sqliteTable(
  'session_costs',
  {
    id: uuidPk(),
    sessionId: text('session_id')
      .notNull()
      .references(() => agentSessions.id, { onDelete: 'cascade' }),
    // The RAW provider model string from `cost:updated.model` — the KEY, deliberately NOT the catalog FK (a divergence
    // from `run_costs`, and a reviewer must not "fix" it back). The FK target is a catalog UUID that resolves to NULL
    // for an UNCATALOGED model (custom, self-hosted, brand-new), and NULLs are DISTINCT under UNIQUE in both SQLite
    // and Postgres — so keying on it would make `ON CONFLICT` never match: every uncataloged egress would insert a
    // NEW row, and two different uncataloged models would collapse into one indistinguishable bucket.
    model: text('model').notNull(),
    // Nullable, WRITTEN (never a dead column, unlike `run_costs.model_id`) join column for catalog enrichment only.
    modelCatalogId: text('model_catalog_id').references(() => modelCatalog.id),
    inputTokens: tokenCount('input_tokens'),
    outputTokens: tokenCount('output_tokens'),
    costMicrocents: microcents('cost_microcents'),
    // ADR-0074 §4's per-model conservative attribution, keyed by the SAME `(session_id, model, is_legacy)` unique
    // index as the realized figure — so the two are joinable per model with no second key to keep in step. Kept
    // out of `cost_microcents` for the same reason the session total keeps them apart: an estimate is not spend.
    conservativeMicrocents: microcents('conservative_microcents'),
    // COUNTERS, not booleans: 2.6.Q can price a model MID-SESSION, so a single (session, model) row folds both priced
    // and unpriced egresses. A boolean would become meaningless the moment that happens (ADR-0070 §6).
    callCount: tokenCount('call_count'),
    unpricedCalls: tokenCount('unpriced_calls'),
    // The legacy discriminator (ADR-0070 §4; column added by migration 0010). 0009's backfill wrote ONE aggregate
    // row per pre-2.6.C session — a
    // real total with no per-model breakdown behind it — and it must be distinguishable from a real model row by the
    // SCHEMA, never by its `model` string. The sentinel string alone cannot do it: `model` is the RAW provider id
    // precisely BECAUSE a custom/self-hosted id can be any non-empty string (see `model` above), so "no real id looks
    // like the sentinel" is the one assumption this table is built to refuse. It rides in the unique index, so a real
    // egress (always `false`) can never upsert ONTO the legacy row — not even one whose model is literally the
    // sentinel. `/cost` branches on this column, not on a string compare.
    isLegacy: integer('is_legacy', { mode: 'boolean' }).notNull().default(false),
    createdAt: epochMs('created_at').notNull(),
    updatedAt: epochMs('updated_at').notNull(),
  },
  (t) => [
    // The upsert target. One row per (session, model, isLegacy) — the shape the additive fold needs, with the legacy
    // aggregate held apart from the real rows by construction rather than by convention.
    uniqueIndex('idx_session_costs_session_model').on(t.sessionId, t.model, t.isLegacy),
    // Covering the `/cost` read: per-session, ordered by spend.
    index('idx_session_costs_session').on(t.sessionId, t.costMicrocents),
    // The DB is the system of record: an empty-string model would be a silent, un-attributable money bucket. The
    // event type already forbids it (`cost:updated.model` is a Zod nonEmptyString) — this is the last line.
    check('session_costs_model_nonempty', sql`${t.model} <> ''`),
  ],
);

// --- 12. media_objects (no FK; the host-owned media retention/GC store, ADR-0042) ---
// The FIRST persisted mutable state outside the ADR-0003 derived-from-run_events model — a retention
// store, NOT a checkpoint store. The content-addressed `media://sha256-<64hex>` handle is the integrity
// hash (no separate checksum). `deleted_at` (the table soft-delete convention) is set by refcount-GC
// byte-reclamation once the grace window (default 7 days, from `last_referenced_at`) has elapsed.
export const mediaObjects = sqliteTable(
  'media_objects',
  {
    id: uuidPk(),
    // A UNIQUE CONSTRAINT (not merely a unique index): the media_references FK targets handle, and a
    // Postgres FK target must be a unique constraint / PK (a bare unique index is insufficient) — so
    // `.unique()` keeps the SQLite↔Postgres parity ([ADR-0005]/[ADR-0042]).
    handle: text('handle').notNull().unique(),
    mimeType: text('mime_type').notNull(),
    modality: text('modality').$type<MediaModality>().notNull(),
    byteLength: integer('byte_length').notNull(),
    durationMs: integer('duration_ms'),
    lastReferencedAt: epochMs('last_referenced_at').notNull(),
    deletedAt: epochMs('deleted_at'),
    createdAt: epochMs('created_at').notNull(),
  },
  (t) => [
    check('media_objects_modality_check', sql`${t.modality} in (${inList(MEDIA_MODALITIES)})`),
    // GC sweep cursor: live objects ordered by recency-of-reference (grace-window candidates first).
    index('idx_media_objects_gc')
      .on(t.lastReferencedAt)
      .where(sql`${t.deletedAt} is null`),
  ],
);

// --- 13. media_references (-> media_objects.handle CASCADE; per-distinct-reference junction, ADR-0042) ---
// One junction serves BOTH refcount/sweep and read_media authz. `scope_kind` is a superset:
// `run`/`node` are refcount + terminal-sweep lifetime entries; `session`/`workspace` are ALSO the
// ADR-0044 read_media authz Scope kinds (authz consults session/workspace rows ONLY — a run/node
// reference never grants read). The refcount derives from the row count; the terminal sweep removes
// the run's `run` rows.
export const mediaReferences = sqliteTable(
  'media_references',
  {
    id: uuidPk(),
    handle: text('handle')
      .notNull()
      .references(() => mediaObjects.handle, { onDelete: 'cascade' }),
    scopeKind: text('scope_kind').$type<MediaScopeKind>().notNull(),
    scopeId: text('scope_id').notNull(),
    createdAt: epochMs('created_at').notNull(),
  },
  (t) => [
    check(
      'media_references_scope_kind_check',
      sql`${t.scopeKind} in (${inList(MEDIA_SCOPE_KINDS)})`,
    ),
    // A scope references a handle at most once (per-distinct-reference; the refcount = row count).
    uniqueIndex('idx_media_references_unique').on(t.handle, t.scopeKind, t.scopeId),
    // Terminal-state sweep (reclaim a run's refs) + read_media authz lookup (by scope).
    index('idx_media_references_scope').on(t.scopeKind, t.scopeId),
    index('idx_media_references_handle').on(t.handle),
  ],
);

// --- 14. model_metadata (NO FK — the DB mirror of the models.dev catalog, ADR-0072) ---
// The durable overlay backing that replaces the `~/.relavium` file cache: price/limits/reasoning/capabilities +
// pure enrichment for EVERY model, refreshed from models.dev. Keyed by `model_id` alone — the SAME key space as the
// generated `CATALOG_SNAPSHOT` (`Record<string, CatalogModel>`), NOT the `model_catalog` UUID — so an entry is
// stored ONCE, provider-agnostic (a `CatalogModel` carries its own `provider`). A LEAF table: no FK referrers, and
// deliberately NO FK to `model_catalog` (keyed `(provider_id, model_id)`) — a models.dev long-tail model may name a
// provider the user has not registered. This table is NEVER the terminal money source: the binary snapshot floor
// stays authoritative for shipped ids; this only BACKS the additive overlay (ADR-0072 point 2).
export const modelMetadata = sqliteTable(
  'model_metadata',
  {
    modelId: text('model_id').primaryKey(),
    // Provider as COERCED text (a `ProviderId`) — no FK, validated against the closed set at the read boundary.
    provider: text('provider').notNull(),
    displayName: text('display_name').notNull(),
    contextWindowTokens: integer('context_window_tokens').notNull(),
    maxOutputTokens: integer('max_output_tokens').notNull(),
    // MONEY — micro-cents per Mtok. Base input/output are NOT NULL: the additive-admission gate requires both
    // FINITE and > 0 (ADR-0072 point 3b), so a row missing either is not a valid catalog entry.
    inputCostPerMtokMicrocents: integer('input_cost_per_mtok_microcents').notNull(),
    outputCostPerMtokMicrocents: integer('output_cost_per_mtok_microcents').notNull(),
    // Cache rates: NULLABLE, and the DB→CatalogModel projection maps NULL → `undefined`, NEVER `0` (ADR-0071 §10 /
    // ADR-0072 point 3c) — `0` means "no discount" and would price a cached read at zero. This is DISTINCT from
    // `model_catalog.cached_input_*` (NOT NULL DEFAULT 0 + a `stated` flag): here NULL carries "absent" directly.
    cachedInputCostPerMtokMicrocents: integer('cached_input_cost_per_mtok_microcents'),
    cacheWriteCostPerMtokMicrocents: integer('cache_write_cost_per_mtok_microcents'),
    // Context-size pricing tiers (`CatalogPriceTier[]`), JSON. NULL ⇒ the flat rate applies at every length.
    contextTiers: jsonText('context_tiers'),
    // Reasoning control shape (`ReasoningControls`), JSON. NULL ⇒ the SAFE default (no reasoning / no knob). It MUST
    // NOT be conflated with `model_catalog.supports_*` booleans, whose default is REJECT — here absent ⇒ safe.
    reasoning: jsonText('reasoning'),
    // Per-model request capabilities (`RequestCapabilities`), JSON. NULL ⇒ accept-ALL (a field is present only when
    // the model REJECTS that parameter) — again the opposite default from the `supports_*` flags.
    requestCapabilities: jsonText('request_capabilities'),
    // --- Pure ENRICHMENT (ADR-0072 point 5): never on the pricing/wire path; freely auto-refreshed for ALL rows. ---
    inputModalities: jsonText('input_modalities'),
    outputModalities: jsonText('output_modalities'),
    knowledgeCutoff: text('knowledge_cutoff'),
    // models.dev publishes no per-model description today; carried NULLABLE at the maintainer's explicit request,
    // populated only when a Relavium-owned overlay or a second source exists (ADR-0072 Negative).
    description: text('description'),
    // --- Bookkeeping ---
    // WHICH store is authoritative for this row's money+wire: `shipped` (pinned to the binary snapshot — money+wire
    // NEVER rewritten by a refresh, only pure-enrichment columns are) vs `refreshed` (a long-tail model admitted
    // through the shared gate). CHECK'd here — unlike `model_catalog.source`, this is an initial CREATE.
    origin: text('origin').$type<CatalogMetadataOrigin>().notNull(),
    // The normalizer version that WROTE this row. A row written by an older normalizer is treated as ABSENT (falls
    // to the snapshot) until a refresh rewrites it (ADR-0072 points 6-7) — checked BEFORE admission.
    catalogSchemaVersion: integer('catalog_schema_version').notNull(),
    refreshedAt: epochMs('refreshed_at'),
    createdAt: epochMs('created_at').notNull(),
    updatedAt: epochMs('updated_at').notNull(),
  },
  (t) => [
    check('model_metadata_origin_check', sql`${t.origin} in (${inList(CATALOG_METADATA_ORIGINS)})`),
    // Money floor AT REST (belt-and-suspenders to the runtime gate). A REFRESHED long-tail row must be priced on
    // both sides (the gate refuses it otherwise); a SHIPPED row is whatever the reviewed snapshot says — a free
    // shipped model (input 0) is legitimate and pinned, so the positivity check is scoped to refreshed rows only.
    check(
      'model_metadata_refreshed_base_price_positive',
      sql`${t.origin} = 'shipped' OR (${t.inputCostPerMtokMicrocents} > 0 AND ${t.outputCostPerMtokMicrocents} > 0)`,
    ),
    index('idx_model_metadata_provider').on(t.provider),
  ],
);

// --- 15. catalog_meta (NO FK — the singleton cursor for the DB-backed catalog, ADR-0072 points 6-7) ---
// AT MOST one row (id = 1): the PK + the `id = 1` CHECK together forbid a second row and any id ≠ 1, but neither
// FORCES a row to exist — it is created LAZILY by the host's first `upsertMeta` (there is no bootstrap seed or
// migration insert), so the table is 0-or-1 rows, never guaranteed-present. Holds the durable state the refresh +
// boot-seed need: the SHA of the
// snapshot the shipped rows were last seeded from (gates re-seeding after a binary upgrade), the normalizer version
// of the stored rows (a read admits DB rows only when it matches the running binary), the two independent per-axis
// TTL cursors (availability = first-party provider lists; catalog = third-party models.dev), and the last upstream
// ETag for conditional revalidation.
export const catalogMeta = sqliteTable(
  'catalog_meta',
  {
    id: integer('id').primaryKey(),
    seededSnapshotSha: text('seeded_snapshot_sha'),
    catalogSchemaVersion: integer('catalog_schema_version'),
    availabilityCheckedAt: epochMs('availability_checked_at'),
    catalogCheckedAt: epochMs('catalog_checked_at'),
    catalogSourceEtag: text('catalog_source_etag'),
    updatedAt: epochMs('updated_at').notNull(),
  },
  (t) => [check('catalog_meta_singleton', sql`${t.id} = 1`)],
);

// --- 16. run_leases (-> runs CASCADE; cross-process run ownership, ADR-0079) ---

/**
 * Which process currently OWNS a run, and the monotonic token that makes a stale owner harmless
 * ([ADR-0079](../../../docs/decisions/0079-cross-process-run-ownership-lease-and-fencing-token.md) §1).
 *
 * **A table, not columns on `runs`.** That row is a DERIVED projection the event fold rewrites
 * (`applyDerived`), so authoritative, non-derived ownership state in it mixes two lifetimes in one row and
 * invites a fold to clobber it. A table is also queryable — by a human diagnosing a stuck run, and by the
 * lease-aware `reconcile()`.
 *
 * **`generation` is the fence.** It increments on every successful acquire — including `reconcile()`'s
 * takeover of an expired lease — and never resets, so a stale owner's token is recognisably OLD rather than
 * merely different. That is the property a `last_seq` CAS cannot give: a CAS stops two processes writing the
 * same row, the fence is what stops the loser continuing to act.
 */
export const runLeases = sqliteTable('run_leases', {
  /** The run this lease owns. PK, not a surrogate id: at most one lease row per run, enforced by the PK. */
  runId: text('run_id')
    .primaryKey()
    .references(() => runs.id, { onDelete: 'cascade' }),
  /** Opaque per-process identity, for the error message a loser shows ("held by …") and for diagnosis. */
  ownerId: text('owner_id').notNull(),
  /**
   * The fencing token, carried on every durable write and checked in the same transaction as the append.
   *
   * Bumps on every successful acquire, but **not monotonic across a run's whole life**: `release` deletes the
   * row, and §4 releases on every gate park, so the next acquire starts at 1 again. What keeps a stale owner
   * out is `(owner_id, generation)` pair-equality plus fail-closed-on-a-missing-row — see ADR-0079 §1's
   * 2026-08-17 amendment, which records the residual risk and what a genuinely monotonic token would cost.
   */
  generation: integer('generation').notNull(),
  /**
   * When this lease stops being live, in epoch ms — compared STORE-SIDE against the injected `deps.now`, so
   * every process on the machine measures against one clock and the platform-free engine gains no second
   * notion of time (ADR-0079 §6). The heartbeat pushes it forward; a takeover requires it to be in the past.
   */
  expiresAt: epochMs('expires_at').notNull(),
  createdAt: epochMs('created_at').notNull(),
  updatedAt: epochMs('updated_at').notNull(),
});

/**
 * The durable effect journal ([ADR-0080](../../../docs/decisions/0080-durable-effect-journal-and-the-tiered-effect-contract.md),
 * canonical contract in [effect-journal.md](../../../docs/reference/shared-core/effect-journal.md)).
 *
 * One row per effect OCCURRENCE. Its purpose is to make a resumed run or session refuse to re-fire an
 * external effect it cannot prove is safe to repeat — a duplicate ticket, deploy, payment or commit.
 *
 * **No foreign key to `runs`, deliberately.** An `ambiguous` / `needs_attention` row is precisely the record
 * an operator needs *after* the run is gone, and `run_leases`' `ON DELETE cascade` would take it with the
 * purge. The correlation is carried as an opaque `scope` string instead, which also lets a SESSION effect —
 * which has no run at all — live in the same table.
 */
export const runEffects = sqliteTable(
  'run_effects',
  {
    id: text('id').primaryKey(),
    /**
     * The correlation with the retry attempt DROPPED — `run:<runId>:<nodeId>` or `session:<sessionId>:<turn>`.
     *
     * The exclusion is the property the resume gate turns on: the node-retry attempt resets to 1 on both a
     * crash-resume and a budget approval, so a scope containing it would miss the very row the gate looks for.
     */
    scope: text('scope').notNull(),
    /** Which effect within the correlation — an ordinal over one model response's tool calls. */
    slot: integer('slot').notNull(),
    toolId: text('tool_id').notNull(),
    /** `1` | `2` | `3` — what the engine can honestly promise for this target. Everything ships as `3` today. */
    tier: integer('tier').notNull(),
    /** `prepared` | `dispatched` | `committed` | `ambiguous` | `needs_attention`. */
    state: text('state').notNull(),
    /**
     * A SHA-256 digest of a canonical JSON serialization of the effective args with every secret-tainted key
     * REMOVED before hashing — not hashed and hidden. A digest is a permanent equality oracle, and a
     * low-entropy secret is recoverable from one by dictionary attack on a `history.db` that may be
     * unencrypted at rest. A collision guard and audit fingerprint, never a replay key.
     */
    argsDigest: text('args_digest').notNull(),
    /** Tier 1 only: what was handed to the target, so a retry reuses it verbatim rather than minting a new one. */
    targetIdempotencyKey: text('target_idempotency_key'),
    /** The tool's result, retained only when re-delivery is possible — its absence is what forces a refusal. */
    resultJson: text('result_json'),
    /** The audit occurrence: node attempt, provider attempt, tool-call id, owning fence. Never used for dedup. */
    attemptJson: text('attempt_json').notNull(),
    createdAt: epochMs('created_at').notNull(),
    updatedAt: epochMs('updated_at').notNull(),
  },
  (table) => [
    // THE dedup constraint. Two processes preparing the same effect collide here, so one loses and learns
    // another attempt exists — which is what makes `prepare` the concurrency boundary rather than a log line.
    uniqueIndex('idx_run_effects_identity').on(table.scope, table.slot, table.toolId),
    // The resume gate's read: every prior record for one correlation, in slot order.
    index('idx_run_effects_scope').on(table.scope),
  ],
);

// --- Inferred row types (select + insert) for each table ---

export type LlmProviderRow = typeof llmProviders.$inferSelect;
export type NewLlmProviderRow = typeof llmProviders.$inferInsert;
export type ModelCatalogRow = typeof modelCatalog.$inferSelect;
export type NewModelCatalogRow = typeof modelCatalog.$inferInsert;
export type AgentRow = typeof agents.$inferSelect;
export type NewAgentRow = typeof agents.$inferInsert;
export type WorkflowRow = typeof workflows.$inferSelect;
export type NewWorkflowRow = typeof workflows.$inferInsert;
export type RunRow = typeof runs.$inferSelect;
export type NewRunRow = typeof runs.$inferInsert;
export type StepExecutionRow = typeof stepExecutions.$inferSelect;
export type NewStepExecutionRow = typeof stepExecutions.$inferInsert;
export type MessageRow = typeof messages.$inferSelect;
export type NewMessageRow = typeof messages.$inferInsert;
export type RunEventRow = typeof runEvents.$inferSelect;
export type NewRunEventRow = typeof runEvents.$inferInsert;
export type RunCostRow = typeof runCosts.$inferSelect;
export type NewRunCostRow = typeof runCosts.$inferInsert;
export type AgentSessionRow = typeof agentSessions.$inferSelect;
export type NewAgentSessionRow = typeof agentSessions.$inferInsert;
export type SessionMessageRow = typeof sessionMessages.$inferSelect;
export type NewSessionMessageRow = typeof sessionMessages.$inferInsert;
export type MediaObjectRow = typeof mediaObjects.$inferSelect;
export type NewMediaObjectRow = typeof mediaObjects.$inferInsert;
export type MediaReferenceRow = typeof mediaReferences.$inferSelect;
export type NewMediaReferenceRow = typeof mediaReferences.$inferInsert;
export type ModelMetadataRow = typeof modelMetadata.$inferSelect;
export type NewModelMetadataRow = typeof modelMetadata.$inferInsert;
export type CatalogMetaRow = typeof catalogMeta.$inferSelect;
export type NewCatalogMetaRow = typeof catalogMeta.$inferInsert;
export type RunLeaseRow = typeof runLeases.$inferSelect;
export type NewRunLeaseRow = typeof runLeases.$inferInsert;
export type RunEffectRow = typeof runEffects.$inferSelect;
export type NewRunEffectRow = typeof runEffects.$inferInsert;
