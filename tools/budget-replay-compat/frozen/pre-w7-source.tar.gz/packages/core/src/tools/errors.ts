/**
 * Typed, discriminated errors thrown by the engine-side `ToolRegistry` dispatch (1.T). They mirror the
 * parser/sandbox error pattern (a base class with a stable `code` discriminant, narrowed on `code` and
 * never on `message`) and carry the closed-enum {@link ErrorCode} a run surfaces plus the retryable
 * split owned by docs/standards/error-handling.md. Messages are **secret-free**: they name a tool id, a
 * field, or a policy reason — never an argument VALUE (a resolved command/URL), a host stack, or a
 * secret. The taxonomy + the mapping rationale live in
 * [tool-registry.md](../../../../docs/reference/shared-core/tool-registry.md#error-taxonomy) and ADR-0037.
 */

import type { ErrorCode } from '@relavium/shared';

import type { ToolId } from './types.js';

/** Stable discriminant for a tool-dispatch failure — callers narrow on `code`, never on `message`. */
export type ToolErrorCode =
  | 'unknown_tool' // the id was not an exact registry match (a misspelled / hallucinated call)
  | 'tool_denied' // a guardrail or grant denial (unlisted command, blocked domain, not granted, missing gate)
  | 'invalid_args' // the effective argument set failed the tool's validator or the secret-taint check
  | 'capability_unavailable' // the required ToolHost capability was not injected (a host/config gap)
  | 'effect_conflict' // another attempt already holds this effect's journal identity (ADR-0080) — a refusal
  | 'effect_unrecorded' // the effect LANDED and its journal record could not be completed (ADR-0080 §7)
  | 'execution_failed' // the host capability threw a non-cancel error
  | 'cancelled'; // the run's AbortSignal fired during the tool — the cooperative-cancel path

/** Base for every tool-dispatch error — narrow on {@link code}, never on `message`. */
export abstract class ToolDispatchError extends Error {
  /** The tool-error discriminant. */
  abstract readonly code: ToolErrorCode;
  /** The closed run `ErrorCode` this maps to (sse-event-schema.md). */
  abstract readonly runErrorCode: ErrorCode;
  /** A pure function of the fault class — owned by error-handling.md. Only `execution_failed` retries. */
  abstract readonly retryable: boolean;
  /** The tool id involved, when one is known (a name, never a secret). */
  readonly toolId?: ToolId;
  /**
   * Whether this failure is safe to FEED BACK to the model as an `isError` tool result for in-turn CONVERSATIONAL
   * recovery (the ADR-0057 `recoverToolFailures` surfaces — `relavium chat` / the Home / one-shot `agent run`;
   * a WORKFLOW node never sets the flag) instead of ending the turn.
   * Default **false** (fatal — the safe direction; a forgotten opt-in just stays fatal). Set true by the specific
   * throwing class ONLY when re-attempting is safe: an IDEMPOTENT host execution failure (a read — no side-effect
   * hazard), or a SCOPE denial refused BEFORE any side effect (a Step-14 fs scope-tier escape / a media scope
   * denial) so the model can adapt to an in-bounds path. A user / guardrail / SSRF / **confidentiality** /
   * side-effecting denial stays false — re-issuing re-denies, would risk a re-execution, or would leak a
   * probe oracle. Distinct from {@link retryable} (a fresh whole-node retry); this is the stricter in-turn re-attempt.
   */
  readonly recoverable: boolean;

  protected constructor(
    message: string,
    toolId: ToolId | undefined,
    cause: unknown,
    recoverable = false,
  ) {
    super(message, cause === undefined ? undefined : { cause });
    if (toolId !== undefined) {
      this.toolId = toolId;
    }
    this.recoverable = recoverable;
  }
}

/** The id was not an exact registry match. The message lists the available ids (names, not secrets). */
export class UnknownToolError extends ToolDispatchError {
  readonly code = 'unknown_tool';
  readonly runErrorCode: ErrorCode = 'tool_failed';
  readonly retryable = false;

  constructor(toolId: ToolId, availableIds: readonly ToolId[]) {
    super(
      `unknown tool \`${toolId}\` — available tools: ${[...availableIds].sort((a, b) => a.localeCompare(b)).join(', ')}`,
      toolId,
      undefined,
    );
    this.name = 'UnknownToolError';
  }
}

/**
 * A guardrail or grant denial — fatal, never retried (re-issuing the same denied call just re-denies).
 * The message names the tool + the policy reason; it never echoes the resolved command/URL value.
 */
export class ToolPolicyError extends ToolDispatchError {
  readonly code = 'tool_denied';
  readonly runErrorCode: ErrorCode = 'tool_denied';
  readonly retryable = false;
  /** The policy that denied the call — a stable label, never an authored value. */
  readonly reason: ToolPolicyDenyReason;

  constructor(toolId: ToolId, reason: ToolPolicyDenyReason, message: string) {
    // A `media_scope_denied` is a SCOPE denial of an idempotent read (read_media) refused before any effect, so
    // it is RECOVERABLE — fed back so the model can adapt (Step 14). Every other guardrail reason stays fatal.
    super(message, toolId, undefined, reason === 'media_scope_denied');
    this.name = 'ToolPolicyError';
    this.reason = reason;
  }
}
export type ToolPolicyDenyReason =
  | 'not_granted' // the id is registered but not in the node's grant (registered ≠ authorized)
  | 'provider_executed' // a provider-executed tool_call the engine must not dispatch (content.ts; ADR-0030)
  | 'command_not_allowed' // the resolved command is not in allowedCommands / allowedCommandGlobs (or empty ⇒ deny-all)
  | 'domain_not_allowed' // the URL host is not in allowedDomains (or empty ⇒ deny-all)
  | 'insecure_url' // the URL is not HTTPS (or has credentials-in-URL)
  | 'gate_required' // git_commit reached without a human-gate approval
  | 'media_scope_denied'; // read_media: the requesting scope is not in the handle's allowedScopes (ADR-0044 §1)

/**
 * A per-tool approval (ADR-0057 EA3) denied the dispatch — the user rejected it, or (fail-closed) the
 * interactive-approval regime was active for a governed-class tool but no `confirm` hook was wired. Carries
 * the **existing** `tool_denied` run code (already absent from `RETRYABLE_ERROR_CODES`), so a user denial is
 * **fatal, never retried** (re-issuing the same call just re-prompts/re-denies — like a guardrail denial). A
 * distinct class from {@link ToolPolicyError} (a guardrail/grant denial of the engine's OWN policy): this is
 * the user's interactive consent verdict, with its own reason discriminant. The message is secret-free.
 */
export class ToolDeniedByUserError extends ToolDispatchError {
  readonly code = 'tool_denied';
  readonly runErrorCode: ErrorCode = 'tool_denied';
  readonly retryable = false;
  /** Why the dispatch was denied — a stable label, never an authored value. */
  readonly reason: ToolApprovalDenyReason;

  constructor(toolId: ToolId, reason: ToolApprovalDenyReason, message: string) {
    super(message, toolId, undefined);
    this.name = 'ToolDeniedByUserError';
    this.reason = reason;
  }
}
export type ToolApprovalDenyReason =
  | 'user_rejected' // the user (or the host's mode policy) rejected the interactive approval prompt
  | 'no_approval_hook' // fail-closed: the approval regime was active for a governed tool but no confirm hook was wired
  | 'approval_error'; // fail-closed: the confirm hook itself threw (a non-abort fault), so consent could not be obtained

/** The effective argument set failed the tool's validator or the secret-taint check. Field names only. */
export class ToolArgsInvalidError extends ToolDispatchError {
  readonly code = 'invalid_args';
  readonly runErrorCode: ErrorCode = 'validation';
  readonly retryable = false;
  /** The offending field paths (names only — never a received value). */
  readonly fields: readonly string[];

  constructor(toolId: ToolId, fields: readonly string[], message: string, cause?: unknown) {
    super(message, toolId, cause);
    this.name = 'ToolArgsInvalidError';
    this.fields = fields;
  }
}

/** The required `ToolHost` capability was not injected — a host/config gap, not the model's fault. */
export class ToolUnavailableError extends ToolDispatchError {
  readonly code = 'capability_unavailable';
  // EA1 (ADR-0055): a missing capability surfaces as its own `tool_unavailable` run code — naming the tool +
  // the unwired arm actionably — never a bare `internal` (an unexpected engine fault). FATAL, like `internal`.
  readonly runErrorCode: ErrorCode = 'tool_unavailable';
  readonly retryable = false;
  /** The missing capability (a name, e.g. `egress`). */
  readonly capability: string;

  constructor(toolId: ToolId, capability: string) {
    super(
      `tool \`${toolId}\` requires the host \`${capability}\` capability, which is not wired`,
      toolId,
      undefined,
    );
    this.name = 'ToolUnavailableError';
    this.capability = capability;
  }
}

/** The host capability threw a non-cancel error. The cause is kept for logs, off the user message. */
/**
 * Another attempt already holds this effect's journal identity
 * ([ADR-0080](../../../../docs/decisions/0080-durable-effect-journal-and-the-tiered-effect-contract.md) §7).
 *
 * A **refusal, not a fault**: the effect was not dispatched, and it must not be retried — a retry re-collides
 * on the same identity, burns the whole node budget, and reports the wrong cause. Its siblings
 * `AppendConflictError` and `LeaseFencedError` are excluded from their retry sets for exactly this reason.
 *
 * It carries `effect_needs_attention` rather than `tool_failed` because that is what it is: another attempt
 * owns this effect and a human, not a retry loop, decides what happened to it.
 */
export class ToolEffectConflictError extends ToolDispatchError {
  readonly code = 'effect_conflict';
  readonly runErrorCode: ErrorCode = 'effect_needs_attention';
  readonly retryable = false;

  constructor(toolId: ToolId, cause?: unknown) {
    super(
      `effect for tool \`${toolId}\` is already claimed by another attempt — not retried, because a retry could repeat it`,
      toolId,
      cause,
      false,
    );
    this.name = 'ToolEffectConflictError';
  }
}

/**
 * A tool's effect landed but its journal record could not be completed
 * ([ADR-0080](../../../../docs/decisions/0080-durable-effect-journal-and-the-tiered-effect-contract.md) §7
 * step 4). The row stays `prepared`, so a resumed run reads it as unresolved and refuses — the conservative
 * answer, reached by a different route.
 *
 * Distinct from `ToolExecutionError` on purpose: here the call SUCCEEDED and only the record failed, so
 * "fix the target and try again" is the one instruction that could make a human repeat a real effect.
 */
export class ToolEffectNeedsAttentionError extends ToolDispatchError {
  // Its OWN discriminant, not `effect_conflict`. The two map to the same `ErrorCode` and the same
  // retryability today, so sharing one read fine — until a future `switch (err.code)` needed to tell "another
  // attempt owns this identity" (nothing happened; a refusal) from "the effect landed and we failed to record
  // it" (something happened; the record is wrong). Those want different words in front of a human.
  readonly code = 'effect_unrecorded';
  readonly runErrorCode: ErrorCode = 'effect_needs_attention';
  readonly retryable = false;

  constructor(toolId: ToolId, cause?: unknown) {
    super(
      `tool \`${toolId}\` completed but its effect record could not be written — the effect may have landed; check the target before repeating it`,
      toolId,
      cause,
      false,
    );
    this.name = 'ToolEffectNeedsAttentionError';
  }
}

export class ToolExecutionError extends ToolDispatchError {
  readonly code = 'execution_failed';
  readonly runErrorCode: ErrorCode = 'tool_failed';
  /**
   * Node-retryable by default, and **not** once the effect has left the process
   * ([ADR-0080](../../../../docs/decisions/0080-durable-effect-journal-and-the-tiered-effect-contract.md) §8,
   * amending [ADR-0037](../../../../docs/decisions/0037-engine-tool-execution-boundary.md)).
   *
   * A retryable failure after a target has acted is the duplicate the effect journal exists to prevent —
   * and the danger is not limited to a dispatch throw: a post-dispatch abort, an `output_mapping` error and
   * a bounding failure all occur after the effect. The registry stamps this `false` for every one of them.
   *
   * Distinct from the inherited `recoverable`, which is a different axis: that gates WITHIN-TURN model
   * recovery, this gates a fresh node dispatch.
   */
  readonly retryable: boolean;

  constructor(
    toolId: ToolId,
    message: string,
    cause?: unknown,
    opts?: { recoverable?: boolean; retryable?: boolean },
  ) {
    // `recoverable` (the inherited base flag) is true ONLY for an IDEMPOTENT tool (a read — no
    // `fs_write`/`egress`/`process`/`os` action), stamped by the registry from `governedAction`; a governed /
    // side-effecting failure (a half-run command, a POST that may have reached the server) stays false so it ends
    // the turn rather than risking a re-execution.
    super(message, toolId, cause, opts?.recoverable ?? false);
    this.retryable = opts?.retryable ?? true;
    this.name = 'ToolExecutionError';
  }
}

/**
 * The run's `AbortSignal` fired during the tool — surfaced on the cooperative-cancel path (`cancelled`),
 * never `tool_failed`, so it composes with ADR-0036's cancel precedence.
 */
export class ToolCancelledError extends ToolDispatchError {
  readonly code = 'cancelled';
  readonly runErrorCode: ErrorCode = 'cancelled';
  readonly retryable = false;

  constructor(toolId: ToolId | undefined, cause?: unknown) {
    super(
      toolId === undefined ? 'tool dispatch cancelled' : `tool \`${toolId}\` cancelled`,
      toolId,
      cause,
    );
    this.name = 'ToolCancelledError';
  }
}
