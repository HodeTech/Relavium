/**
 * `AgentSession` (1.V) — Relavium's **agent-first entry point**: an ongoing, multi-turn conversation
 * bound to **one** agent + its fallback chain, a first-class peer of a workflow run that **reuses the
 * same execution substrate** rather than a parallel implementation
 * ([ADR-0024](../../../../docs/decisions/0024-agent-first-entry-point-agentsession.md),
 * [agent-session-spec.md](../../../../docs/reference/contracts/agent-session-spec.md)). Each
 * `sendMessage` drives **one turn through the same turn core** a workflow `agent` node uses
 * ({@link runAgentTurn} — the correlation-agnostic core the `AgentRunner` (1.O) also wraps), so a
 * session's streaming, tool-call loop, and provider fallback are identical to a node's; only the entry
 * point and lifetime differ.
 *
 * **Scope (1.V).** This is the in-memory session DRIVER: the lifecycle (`start` / `sendMessage` /
 * `cancel`), the conversation accumulator, the session-wide cost total, the hard turn cap, and mapping a
 * classified {@link AgentTurnError} to a `session:turn_completed` error. It emits session events through
 * an **injected {@link SessionEventSink}** — wiring that sink onto the shared `RunEventBus` (per-session
 * `sequenceNumber` + gap/resync + a `SessionHandle`) is **1.W**; DB persistence + the durable
 * `SessionMessage` schema is **1.X**; resume is **1.Y**; the export serializer is **1.Z**. 1.V keeps the
 * transcript **in-memory** (`LlmMessage[]`, the in-flight content form) and persists nothing.
 *
 * The hard turn cap is the session's loud DoS fail-safe — distinct from `[chat].max_messages` (a
 * history-**trim** threshold that silently continues; later phases) and from the turn core's within-turn
 * `maxToolTurns` tool-loop guard. A `sendMessage` past the cap surfaces **loudly** with **no egress**:
 * `session:turn_completed` carrying `error.code: 'turn_limit'` — never a silent stop.
 */

import type {
  Agent,
  AbortSignalLike,
  AgentApprovalRequestedEvent,
  ErrorCode,
  ReasoningEffort,
  SessionContext,
  SessionEvent,
  SessionStopReason,
  ToolPolicy,
  EffectCorrelation,
  EffectDispatchPort,
} from '@relavium/shared';
import { unwiredEffectJournal } from '@relavium/shared';

import { WorkflowGraphError, type GraphIssue } from '../errors.js';
import { collectAgentCeilingIssues } from '../limits.js';
import { markUntrusted, unwrapUntrusted, type Untrusted } from '../tools/untrusted.js';
import { authoredSystemPrompt, type AuthoredSystemPrompt } from './authored-system-prompt.js';
import { buildTurnMessages } from './turn-messages.js';
import {
  ToolDefSchema,
  type FallbackPlanEntry,
  type LlmMessage,
  type LlmProvider,
  type PricingOverlay,
  type ProviderId,
  type ToolDef as LlmToolDef,
} from '@relavium/llm';

import {
  ToolCancelledError,
  ToolDeniedByUserError,
  ToolDispatchError,
  ToolPolicyError,
} from '../tools/errors.js';
import type {
  ConfirmActionHook,
  ProcessResult,
  ToolCallPart,
  ToolDef,
  ToolDispatchContext,
  ToolId,
  ToolRegistry,
} from '../tools/types.js';
import { modelVisibleDescription } from '../tools/types.js';
import { delegateAvailable, type ToolDelegates } from '../tools/delegates.js';
import {
  AgentTurnError,
  DEFAULT_AGENT_TURN_LIMITS,
  runAgentTurn,
  type AgentTurnLimits,
  type AgentTurnResult,
  type ChainCapabilities,
  type PreEgressHook,
} from './agent-turn.js';
import { BudgetPauseError } from './budget-governor.js';
import type { AbortControllerLike } from './execution-host.js';
import { effortToSend, gateReasoningEffort } from './reasoning-effort.js';
import type {
  EffortGateResult,
  ReasoningCapCheck,
  ResolveEffortTiers,
} from './reasoning-effort.js';
import type { NodeStreamEvent } from './node-executor.js';
import type { SessionResumeState } from './session-resume.js';

/** The default hard turn cap when {@link SessionDeps.maxTurns} is omitted — a finite DoS fail-safe. */
export const DEFAULT_SESSION_MAX_TURNS = 50;

/** The auto-compaction trigger fraction when {@link SessionDeps.compactThreshold} is omitted (ADR-0062). */
export const DEFAULT_COMPACT_THRESHOLD = 0.8;

/**
 * The hard output cap on a compaction summary (ADR-0062) — passed as the summariser turn's `maxTokens` so the
 * preamble a compaction produces is BOUNDED (an unbounded summary could defeat compaction). It also anchors
 * the auto-compaction "projected floor" thrash guard: if `base system + kept exchange + this bound` would
 * still exceed the budget, compaction cannot help and is skipped.
 */
export const COMPACTION_MAX_SUMMARY_TOKENS = 4096;

/**
 * The context-compaction summariser system prompt has MOVED to `authored-system-prompt.ts`
 * ([ADR-0081](../../../../docs/decisions/0081-the-compaction-summary-is-untrusted-and-the-system-prompt-is-branded.md) §1).
 *
 * It is authored text, and `AgentTurnParams.system` now accepts only the branded type — so it lives beside
 * the one constructor that can mint one, reachable as `authoredSystemPrompt({ kind: 'engine', prompt:
 * 'compaction' })`. It was the engine's third authored producer and the reason that arm exists at all.
 */

/**
 * The classified result of a {@link AgentSession.compact} (ADR-0062) — a discriminated union so the host renders
 * each case explicitly. `compacted` carries the token deltas + the summary text (the host shows an inline
 * notice + an expandable summary); `nothing_to_compact` means there was ≤1 exchange to fold; `failed` is a
 * secret-free summarisation fault (the caller degrades to `/trim`); `cancelled` = an `Esc`/cancel mid-summary.
 */
export type CompactionResult =
  | {
      readonly kind: 'compacted';
      readonly reason: 'manual' | 'auto-threshold';
      readonly summary: string;
      readonly keptMessageCount: number;
      readonly tokensBefore: number;
      readonly tokensAfter: number;
      readonly summaryTokens: { readonly input: number; readonly output: number };
    }
  | { readonly kind: 'nothing_to_compact' }
  | { readonly kind: 'failed'; readonly message: string }
  | { readonly kind: 'cancelled' };

/**
 * The result of a {@link AgentSession.trimHistory} (ADR-0062) — a deterministic, no-LLM drop. `trimmed` carries
 * the kept/dropped counts; `nothing_to_trim` means the history was already within the bound.
 */
export type TrimResult =
  | {
      readonly kind: 'trimmed';
      readonly keptMessageCount: number;
      readonly droppedMessageCount: number;
    }
  | { readonly kind: 'nothing_to_trim'; readonly messageCount: number };

/** Distribute `Omit` across each union member so the discriminated union (and `.type` narrowing) survives. */
type DistributiveOmit<T, K extends PropertyKey> = T extends unknown ? Omit<T, K> : never;

/**
 * A session lifecycle event body minus the envelope (`sessionId` / `timestamp` / `sequenceNumber`) the
 * transport stamps — the session counterpart of {@link NodeStreamEvent}. 1.V produces the body; 1.W's
 * bus wiring attaches the correlation key + the per-session monotonic sequence.
 */
export type SessionLifecycleEvent = DistributiveOmit<
  SessionEvent,
  'sessionId' | 'timestamp' | 'sequenceNumber'
>;

/**
 * The per-tool approval body (ADR-0057 EA5), envelope-less — a **session-carried** event the chat approval
 * regime emits through the sink. It is NOT a turn-core in-node event (so not in `NodeStreamEvent` / the run
 * path). The ENGINE emits it: the registry's `confirmDispatch` calls the dispatch context's
 * `emitApprovalRequested` port (which {@link AgentSession} wires to this sink, stamping the turn's `nodeId`)
 * for every governed dispatch, just before invoking the host's `ConfirmActionHook`.
 */
export type SessionApprovalStreamEvent = DistributiveOmit<
  AgentApprovalRequestedEvent,
  'runId' | 'sessionId' | 'timestamp' | 'sequenceNumber'
>;

/**
 * Everything a session emits, envelope-less: the `session:*` lifecycle/side bodies, the dual-envelope
 * in-turn bodies the turn core produces (`agent:token` / `agent:reasoning` / `agent:tool_call` /
 * `agent:tool_result` / `cost:updated`), and the engine-emitted `agent:approval_requested` body (ADR-0057 EA5 — the registry's
 * `confirmDispatch` emits it via the dispatch context's `emitApprovalRequested`). The injected sink receives
 * these; 1.W routes them onto the bus.
 */
export type SessionStreamEvent =
  | SessionLifecycleEvent
  | NodeStreamEvent
  | SessionApprovalStreamEvent;

/** The injected emission port. 1.V emits through it; 1.W implements it over the shared `RunEventBus`. */
export type SessionEventSink = (event: SessionStreamEvent) => void;

/**
 * The **reseat-less mode** projection (ADR-0057) — the engine-side, **mode-agnostic** per-turn policy a host
 * sets on the SAME session instance (no reseat, no tool-context loss). The ask / plan / accept-edits / auto
 * **enum lives in the host** (`apps/cli`, [ADR-0055](../../../../docs/decisions/0055-cli-host-capability-seam-tool-environment-factory.md)):
 * the host maps its current mode to this policy and pushes it via {@link AgentSession.setTurnPolicy}; the
 * session **snapshots it at each turn start**, so a mid-turn change applies on the next turn. Setting a policy
 * **activates the interactive-approval regime** for governed tools (the dispatch context's `approval` is
 * present), so a write/process/egress dispatch requires a `confirm` decision — fail-closed if `confirm` is
 * absent (ADR-0057 EA3). Absent (the default) ⇒ today's behavior: all granted tools advertised, no approval
 * regime (the workflow author-trust floor).
 */
export interface SessionTurnPolicy {
  /**
   * Which of the agent's granted tools to **advertise** to the model this turn (the mode advertise-filter):
   * `true` keeps the tool in the model-visible set. A tool filtered OUT is never offered, but the `confirm`
   * floor remains authoritative if the model names it anyway (best-effort filter + fail-closed gate). Absent
   * ⇒ advertise every granted tool.
   */
  readonly advertise?: (toolId: ToolId) => boolean;
  /**
   * The host's interactive per-tool approval hook ([ConfirmActionHook]{@link ConfirmActionHook}) threaded into
   * the dispatch context's approval regime. Absent **while a policy is set** ⇒ fail-closed (a governed
   * dispatch is denied — a wiring bug can't let `ask` mode write). The host's hook owns the mode policy
   * (ask denies writes, accept-edits prompts, auto auto-approves), the once/always cache, and protected paths.
   */
  readonly confirm?: ConfirmActionHook;
}

/**
 * The session's injected dependencies — **platform capabilities only**, mirroring `AgentRunnerDeps`
 * (1.O). `resolveProvider` keeps an adapter from ever being imported by core; `keyFor` / `sleep` /
 * `now` / `onAuthError` forward into the per-turn `FallbackChain`; `preEgress` is the ADR-0028 budget
 * hook (no-op default; 1.AC supplies the estimator for both entry points through the same seam).
 */
export interface SessionDeps {
  /** Resolve an authored provider id to its concrete adapter instance; `undefined` ⇒ a host-wiring gap. */
  readonly resolveProvider: (providerId: ProviderId) => LlmProvider | undefined;
  /** The shared tool registry (1.T) the agent dispatches through (ADR-0037). */
  readonly registry: ToolRegistry;
  /** The registry's tool defs — the source of the LLM-visible schema for the agent's granted tools. */
  readonly tools: readonly ToolDef[];
  /** Host credential resolver — forwarded into the chain; never logged / stored / inspected by core. */
  readonly keyFor: ChainCapabilities['keyFor'];
  /** Host delay primitive (the engine has no ambient `setTimeout`). */
  readonly sleep: ChainCapabilities['sleep'];
  /** Optional injectable clock for the chain's cooldown bookkeeping. */
  readonly now?: ChainCapabilities['now'];
  /** Optional single out-of-band credential refresh (host-owned). */
  readonly onAuthError?: ChainCapabilities['onAuthError'];
  /**
   * ADR-0082 §6's per-attempt deadline primitives. **Both or neither** — a chain given only one keeps the
   * pre-ADR-0082 unbounded behaviour, and an unbounded wait on a provider that ignores its abort signal is
   * the hang the deadline exists to remove.
   */
  readonly setTimer?: ChainCapabilities['setTimer'];
  /** Override the per-attempt deadline (default 120s). Must be finite and positive. */
  readonly attemptTimeoutMs?: ChainCapabilities['attemptTimeoutMs'];
  /**
   * Create a fresh abort controller — injected so core never names the ambient global.
   *
   * Serves TWO purposes since ADR-0082: the per-turn cancel it was built for, and the per-attempt
   * deadline's merged signal. One dep rather than two, because a host that can make one can make both and a
   * second field would only be a way to wire half of it.
   */
  readonly newAbortController: () => AbortControllerLike;
  /** The emission port — 1.V emits session/in-turn bodies here; 1.W wires it onto the `RunEventBus`. */
  readonly emit: SessionEventSink;
  /**
   * The producer-await half of ADR-0036's no-drop, bounded-per-consumer buffering, for the SESSION path
   * (`CR-30`). Resolves once this session's consumer has drained to its ceiling.
   *
   * **This path had no backpressure at all, not merely advisory backpressure.** `SessionHandle` has always
   * exposed `whenConsumersReady`, and nothing ever awaited it — so a long streamed reply grew the buffer for
   * as long as the model talked. The workflow path at least throttled once per node. `AgentSession` is a
   * co-equal first-class entry point (ADR-0024), so the bound has to reach it too.
   *
   * Late-bound by construction on every host: the handle is created FROM the session (it closes over
   * `session.cancel()`), so the session cannot hold it at construction. A host therefore passes a thunk that
   * reads the handle once it exists. Optional — absent means "never throttle", the pre-`CR-30` behaviour.
   */
  readonly whenReady?: () => Promise<void>;
  /**
   * Builds this session's effect journal from a correlation (ADR-0080) — a FACTORY, not a port, because the
   * correlation carries the TURN and only the session knows which turn it is on.
   *
   * A port with the correlation frozen at construction was the first shape here, and it was wrong in a way a
   * review had to RUN to find: every turn shared `session:<id>:0` while the slot ordinal restarts each turn,
   * so a user's SECOND effectful request in one chat collided with their first on the journal's UNIQUE
   * identity and was refused — permanently, since nothing sweeps the row. A host that leaves this unset gets
   * `unwiredEffectJournal()`, which rejects: absence is fail-closed, not fail-open.
   *
   * This is where CR-12 EXTENDS `TurnMoneyPort`'s precedent rather than reusing it: the money port is
   * deliberately run-path-only, while a session's external effects need journaling exactly as a run's do.
   */
  readonly effects?: (correlation: EffectCorrelation) => EffectDispatchPort;
  /** The workflow-wide tool policy threaded into dispatch (default `{}` ⇒ deny-all for gated tools). */
  readonly toolPolicy?: ToolPolicy;
  /** Within-turn tool-loop bounds passed to the turn core (default {@link DEFAULT_AGENT_TURN_LIMITS}). */
  readonly limits?: AgentTurnLimits;
  /** The session hard turn cap (default {@link DEFAULT_SESSION_MAX_TURNS}); 0/absent ⇒ the default. */
  readonly maxTurns?: number;
  /** Pre-egress budget hook (default no-op; 1.AC fills it — ADR-0028). */
  readonly preEgress?: PreEgressHook;
  /**
   * The user-pricing overlay (2.5.G S10, ADR-0065 §2) — host-injected (like {@link keyFor}) from the
   * `model_catalog` `source='user'` rows, threaded into the turn's REALIZED cost tracker so a user-priced model
   * the static registry lacks is folded into the cumulative cost (which `updateCost` feeds to the governor, so
   * `max_cost_microcents` enforces it). Absent ⇒ static-only pricing. `@relavium/core` never imports `@relavium/db`.
   */
  readonly resolvePrice?: PricingOverlay;
  /**
   * WHICH reasoning tiers the bound model accepts ([ADR-0071](../../../../docs/decisions/0071-models-dev-as-the-model-metadata-source.md) §6)
   * — the host-injected per-model catalog projection, the same one {@link AgentRunnerDeps.resolveEffortTiers}
   * takes. Gates the `reasoningEffort` send: the effective tier (session override → the agent's authored tier) is
   * passed to a turn only when the model is on record as taking it.
   *
   * It replaced a boolean. `gpt-5.4-pro` reasons **and rejects `low`** — a boolean answered `true` for it and the
   * tier went to the provider unexamined. Absent / `undefined` / an empty set ⇒ withheld, never guessed.
   * `@relavium/core` never imports the catalog, so the host injects the lookup.
   */
  readonly resolveEffortTiers?: ResolveEffortTiers;
  /**
   * Does a budget-shaped model withhold the accepted tier because THIS turn's `max_tokens` leaves no room for its
   * minimum thinking budget (review M6)? Host-injected (it reads the catalog's budget range); absent ⇒ the cap is
   * not checked and a small `max_tokens` withholds thinking silently, as before. Paired with `max_tokens` at the
   * gate so the withhold becomes a `capped` verdict the host can voice.
   */
  readonly withheldByCap?: ReasoningCapCheck;
  /**
   * Called when the effective tier is WITHHELD because the bound model does not take it — the session mirror of
   * {@link AgentRunnerDeps.onEffortWithheld}. The surface decides where the sentence goes (the CLI puts it in the
   * transcript's notice channel); the engine only reports that it happened, and what the model WOULD accept.
   */
  readonly onEffortWithheld?: (result: EffortGateResult, model: string) => void;
  /**
   * Feed the running session cost to a budget governor so a host that wires {@link preEgress} to
   * `BudgetGovernor.checkPreEgress` also keeps the governor's cumulative total current (ADR-0028, 1.AC).
   * Called after each `cost:updated` with the session-wide cumulative; without it the governor would stay
   * pinned at 0 and only single-call estimates would trip the cap (so a tool-looping chat would not fail
   * safe). No-op by default; the host wires it to `governor.updateCost`.
   */
  readonly updateCost?: (cumulativeCostMicrocents: number) => void;
  /**
   * Await the budget governor's conservative-commitment durability barrier (ADR-0074 §2).
   *
   * §2 requires that "the next provider attempt AND the enclosing turn completion wait for the commitment's
   * durability acknowledgement". The governor's own barrier covers the first half on every surface; the engine
   * covers the second at each node boundary. This is the SESSION's half of it, and without it a chat could
   * report a turn complete — returning from `sendMessage`, letting the process exit — while the commitment for
   * a possibly-billed call had not reached the database, or had failed to and would surface only later, blamed
   * on an unrelated turn.
   *
   * Rejects on a durability failure; the caller turns that into the turn's terminal. No-op by default; the host
   * wires it to `governor.flushCommitments`.
   */
  readonly flushBudgetCommitments?: () => Promise<void>;
  /**
   * Seed the host governor's CONSERVATIVE total on resume ([ADR-0074](../../../../docs/decisions/0074-durable-conservative-budget-commitments.md) §4).
   *
   * Separate from {@link updateCost} because the two figures are separate by design: one is realized spend, the
   * other an estimate the provider may already have billed. Folding them would present an upper bound as an
   * invoice. No-op by default; the host wires it to `governor.restoreConservativeCost`.
   */
  readonly restoreConservativeCost?: (conservativeCostMicrocents: number) => void;
  /**
   * Automatic context compaction (ADR-0062) — the surface-mapped form of `[chat].auto_compact`. When not
   * `false` (absent ⇒ enabled), after a turn completes the session compacts if the turn's real input tokens
   * exceed {@link SessionDeps.compactThreshold} × the serving model's context window. The host wires this from
   * config; hardcoding it here would re-orphan the config field.
   */
  readonly autoCompact?: boolean;
  /** The auto-compaction trigger fraction (`[chat].compact_threshold`; absent ⇒ {@link DEFAULT_COMPACT_THRESHOLD}). */
  readonly compactThreshold?: number;
  /**
   * The history-trim bound (`[chat].max_messages`) the auto-compaction FAILURE path degrades to (ADR-0062): a
   * summarisation fault falls back to a deterministic, zero-cost `/trim` to `maxMessages`. Absent ⇒ no
   * fallback trim (the un-compacted turn proceeds; a genuine overflow surfaces via the error taxonomy).
   */
  readonly maxMessages?: number;
}

/** Construction params: a caller-minted `sessionId`, the bound agent + its `agentRef`, the context, deps. */
export interface AgentSessionParams {
  /** Process-unique id (the caller mints it via the host id source); carried on every session event. */
  readonly sessionId: string;
  /** The agent's authored id — recorded on `session:started` and used as the in-turn event `nodeId`. */
  readonly agentRef: string;
  /** The resolved agent config the session binds for its whole lifetime (no mid-session switching). */
  readonly agent: Agent;
  /** The workspace situation the session runs against (fs-scope tier, working dir, ctx variables). */
  readonly context: SessionContext;
  readonly deps: SessionDeps;
}

type SessionStatus = 'created' | 'idle' | 'running' | 'cancelled';

/** A typed, secret-free session API-misuse error (never a raw string throw — error-handling.md). */
export class SessionStateError extends Error {
  override readonly name = 'SessionStateError';
  constructor(
    readonly code: 'not_started' | 'already_started' | 'not_active',
    message: string,
  ) {
    super(message);
  }
}

type PlanResult =
  | { readonly ok: true; readonly entries: readonly FallbackPlanEntry[] }
  | { readonly ok: false; readonly message: string };

/**
 * The classified result of a `!`-shell {@link AgentSession.runUserCommand} (ADR-0061). A discriminated union so
 * the host renders each case explicitly and no raw error escapes:
 * - `ran` — the command executed; `stdout`/`stderr` are the process-arm–bounded output (the host applies a second
 *   injection bound + its own truncation marker before feeding them to the model as UNTRUSTED context — so this
 *   type does NOT carry a `truncated` flag, which would describe a different, model-facing bounding pass over data
 *   the caller never receives). `exitCode` may be non-zero (a normal command failure, still `ran`).
 * - `denied` — refused BEFORE any side effect: `allowlist: true` ⇒ the command is not in `[chat].allowed_commands`
 *   (the host shows the actionable opt-in hint); `false` ⇒ an interactive approval reject / protected-path denial.
 * - `failed` — a transient execution/wiring fault (a spawn error, a capability gap) — `message` is secret-free.
 * - `cancelled` — the session was cancelled/aborted mid-run.
 */
export type UserCommandOutcome =
  | {
      readonly kind: 'ran';
      readonly exitCode: number;
      readonly stdout: string;
      readonly stderr: string;
    }
  | { readonly kind: 'denied'; readonly allowlist: boolean; readonly message: string }
  | { readonly kind: 'failed'; readonly message: string }
  | { readonly kind: 'cancelled' };

/** Structural guard for the `run_command` dispatch result (a {@link ProcessResult}) — validates the FULL shape at
 *  the boundary via `in`-narrowing (no cast), so a future tool-shape drift is caught, not silently mis-read. */
function isProcessResult(value: unknown): value is ProcessResult {
  return (
    typeof value === 'object' &&
    value !== null &&
    'exitCode' in value &&
    typeof value.exitCode === 'number' &&
    'stdout' in value &&
    typeof value.stdout === 'string' &&
    'stderr' in value &&
    typeof value.stderr === 'string' &&
    'durationMs' in value &&
    typeof value.durationMs === 'number'
  );
}

/**
 * Drive a multi-turn agent conversation over the shared turn core. Construct with a caller-minted
 * `sessionId`, call {@link start} once, then {@link sendMessage} per user turn; {@link cancel} aborts an
 * in-flight turn. Events flow through the injected {@link SessionEventSink}.
 */
/**
 * The primary chain entry's attempt budget on the SESSION path (chat / one-shot `agent run`).
 *
 * **2, not 1**, and the difference is load-bearing: a session has no above-chain retry loop, so the chain is
 * the only retry there — and a budget of 1 makes even the chain's own backoff unreachable (`attempt < budget`).
 * Until #276 the vendor SDK's internal retry hid that; with the SDK correctly out of the retry business, a
 * transient 429 would end the user's turn with no wait at all. Two attempts restores a single polite retry
 * without touching the authored node-retry budget, which does not exist on this path.
 * ADR-0040 carries the dated amendment.
 */
const SESSION_PRIMARY_MAX_ATTEMPTS = 2;

export class AgentSession {
  readonly sessionId: string;

  readonly #agentRef: string;
  readonly #agent: Agent;
  readonly #context: SessionContext;
  readonly #deps: SessionDeps;
  readonly #maxTurns: number;
  readonly #limits: AgentTurnLimits;

  /** The in-memory conversation (in-flight `ContentPart` form); the turn core copies it, never mutates it. */
  readonly #messages: LlmMessage[] = [];
  /**
   * Turns where a provider actually engaged — a success, or a failure whose {@link AgentTurnError.engaged} is
   * `true` (a non-skipped attempt ran). The hard cap counts ONLY these, so a pre-egress failure (no plan
   * entries, a budget refusal, a pre-flight cancel) never burns a turn the model never took.
   */
  #turnCount = 0;

  /**
   * The last turn's real accumulated usage, captured on the success path just before the durability flush.
   *
   * Exists so an unclassified failure AFTER a provider engaged — in practice a `flushBudgetCommitments`
   * rejection — can report what was actually billed instead of `{0,0}` (`CR-02`). Cleared at the top of each
   * turn so a later failure can never inherit an earlier turn's numbers.
   */
  #lastEngagedUsage: { input: number; output: number } | undefined;
  /** Session-wide running cost total, authoritatively stamped onto every `cost:updated`. */
  #cumulativeCostMicrocents = 0;
  #status: SessionStatus = 'created';
  /** The in-flight turn's controller, so {@link cancel} can abort it; `undefined` between turns. */
  #abort: AbortControllerLike | undefined;
  /**
   * The reseat-less mode policy (ADR-0057), mutated by {@link setTurnPolicy} and **snapshotted per turn**.
   * Present ⇒ the interactive-approval regime is active + the advertise-filter applies. `undefined` ⇒
   * today's behavior (all granted tools advertised, no approval regime).
   */
  #turnPolicy: SessionTurnPolicy | undefined;
  /**
   * The session-level reasoning-effort OVERRIDE ([ADR-0066](../../../../docs/decisions/0066-normalized-reasoning-effort-control.md) §5),
   * mutated by {@link setReasoningEffort} and read per turn (like {@link #turnPolicy}). It is the top tier of the
   * per-turn resolution `session override → agent.reasoning_effort → unset`, so an interactive surface (the
   * `/models` effort sub-step, a `/effort` command) changes effort mid-session with **no reseat** — effort is a
   * per-turn field (never plan-changing), so a reseat (which exists for a *model* change) would be unwarranted
   * teardown. `undefined` ⇒ no override (fall through to the agent's authored tier).
   */
  #reasoningEffort: ReasoningEffort | undefined;
  /**
   * Set by {@link abort} to mark the in-flight turn as **user-aborted** (EA7) — distinct from `cancel()`'s
   * terminal `'cancelled'` status. The `sendMessage` catch reads it to settle the turn as
   * `session:turn_completed{stopReason:'aborted'}` and keep the session alive (→ `idle`). Cleared each turn.
   */
  #abortingTurn = false;
  /** Monotonic counter for the synthetic `run_command` tool-call id of a `!`-shell dispatch ({@link runUserCommand}). */
  #userCommandSeq = 0;
  /** Memoized provider fallback plan (the agent binding is fixed for the session). */
  #plan: PlanResult | undefined;
  /**
   * The compaction summary (ADR-0062, **placed** per [ADR-0081](../../../../docs/decisions/0081-the-compaction-summary-is-untrusted-and-the-system-prompt-is-branded.md))
   * — the folded-away earlier conversation. Set by {@link compact}, restored on {@link resume}, untouched by
   * {@link trimHistory} (a trim drops older turns without summarising, so a prior compact's summary survives).
   *
   * **`Untrusted<string>`, and named for what it is rather than where it used to go.** It was
   * `#contextPreamble: string`, prepended to the agent's system prompt — and "preamble" names exactly the
   * placement ADR-0081 removes, so keeping the name is how the next reader puts it back. It carries the
   * engine's existing untrusted brand (no new primitive), and exactly one place unwraps it:
   * {@link buildTurnMessages}, which puts it in a user-role content part.
   */
  #compactionSummary: Untrusted<string> | undefined;
  /**
   * Set on a CLEAN turn success to the settled turn's model + real input tokens, so `sendMessage` can run the
   * after-turn auto-compaction check (ADR-0062) AFTER the turn fully settles (status back to idle). Cleared
   * once consumed. Never set on an error/abort/cancel/cap path — those never auto-compact.
   */
  #autoCompactPending: { readonly model: string; readonly inputTokens: number } | undefined;

  constructor(params: AgentSessionParams, opts?: { readonly admit?: boolean }) {
    // **The session's half of ADR-0086 §6, and it is a CONSTRUCTOR check on purpose.** `relavium agent run`
    // and `relavium chat` never build a workflow graph, so the compiler's ceiling pass never sees their
    // agent — and `retry.max` / `fallback_chain` / `max_attempts` are exactly the values this path consumes.
    // Rejecting here, before any turn, is the session's equivalent of "the run never starts": no provider
    // call, no tool dispatch, no money. The SAME validator the compiler calls, so an agent file cannot be
    // admitted by `chat` and rejected by a workflow that references it.
    //
    // **A RESUME does not re-admit, and that is not a loophole — it is the only humane answer.** A resumed
    // session runs the agent SNAPSHOT frozen at session start: the file it came from may have changed or be
    // gone, so an author has nothing to edit. Applying a ceiling here would make every transcript persisted
    // before this ADR permanently unopenable, with no lever for the user and no warning. Admission governs
    // what is ADMITTED; ADR-0083 draws the same line for a run resume, which verifies what it was admitted
    // with rather than admitting it again. The snapshot keeps its old budget; every ceiling still applies to
    // the next session the user starts.
    if (opts?.admit !== false) {
      const ceilingIssues: GraphIssue[] = [];
      collectAgentCeilingIssues(params.agent, ceilingIssues);
      if (ceilingIssues.length > 0) {
        throw new WorkflowGraphError(ceilingIssues);
      }
    }
    this.sessionId = params.sessionId;
    this.#agentRef = params.agentRef;
    this.#agent = params.agent;
    this.#context = params.context;
    this.#deps = params.deps;
    const max = params.deps.maxTurns;
    this.#maxTurns = max === undefined || max <= 0 ? DEFAULT_SESSION_MAX_TURNS : max;
    this.#limits = params.deps.limits ?? DEFAULT_AGENT_TURN_LIMITS;
  }

  /**
   * Resume a session in a NEW process (1.Y) from its reconstructed state
   * ({@link reconstructSessionState}, built from the persisted transcript). Preloads the in-flight
   * transcript, the hard-cap turn count, and the running cost, then lands directly at `idle` **without**
   * emitting `session:started` — the session already started in the prior process; re-emitting it would
   * double a terminal-less lifecycle event. The next {@link sendMessage} continues the conversation. This
   * **replaces** {@link start}: the returned session is past `created`, so calling `start()` on it throws.
   */
  static resume(params: AgentSessionParams, state: SessionResumeState): AgentSession {
    // `admit: false` — see the constructor. A resume continues a session that was already admitted, on a
    // frozen snapshot its user cannot edit; re-admitting it would strand their transcript.
    const session = new AgentSession(params, { admit: false });
    session.#messages.push(...state.messages);
    session.#turnCount = state.turnCount;
    // **`#userCommandSeq` is deliberately NOT restored, and the reason is a limitation rather than a choice.**
    //
    // An earlier attempt seeded it from `state.turnCount`, which is wrong: that counts completed ASSISTANT
    // turns and has no relationship to how many `!`-commands were issued. A review reproduced the resulting
    // false refusal — two `!`-commands inside one turn window, then a `/models` reseat, and the next command
    // reuses a slot and is rejected as "already claimed" for something never run before.
    //
    // Reconstructing it honestly needs a durable source, and there is none: `!`-commands never enter the
    // transcript, and the platform-free engine cannot read `run_effects`. So the counter restarts, and the
    // consequence is recorded in effect-journal.md §14 rather than papered over: a `!`-command issued after a
    // resume, in a turn window that already had one, can be refused as a false duplicate. It fails CLOSED —
    // a refusal, never a repeated effect — which is the safe direction, and it is fixed by persisting the
    // counter with the session row when a surface makes repeated in-window shell commands worth the schema.
    session.#cumulativeCostMicrocents = state.cumulativeCostMicrocents;
    // ADR-0062: restore the compaction preamble so a compacted session stays compacted across resume AND a
    // model reseat (which reuses this same reconstruct→resume path); without it, resume would silently
    // re-expand the folded history into the (possibly smaller-window) new model.
    session.#compactionSummary = state.compactionSummary;
    // Sync a host-wired budget governor with the carried-over spend so the FIRST resumed turn's pre-egress
    // check sees the real cumulative — not 0 — before any cost:updated fires (mirrors #onTurnEmit). Without
    // this, a resumed session's first turn could bypass a near-exhausted budget cap.
    session.#deps.updateCost?.(state.cumulativeCostMicrocents);
    // ADR-0074 §2/§4: BOTH totals, together, before the session is idle and can take a turn. The realized sync
    // above is not enough on its own — a conservative commitment is money the provider may ALREADY have billed
    // for an attempt that returned no trustworthy usage, so a resumed cap that forgets it hands already-owed
    // headroom back on the first turn, which is the bypass ADR-0074 exists to close. The governor takes the
    // maximum rather than assigning, so this can never LOWER a total a live governor already holds.
    session.#deps.restoreConservativeCost?.(state.conservativeCostMicrocents);
    session.#status = 'idle';
    return session;
  }

  /** Open the session: emit `session:started` and move to idle. Idempotent-guarded (one start per session). */
  start(): void {
    if (this.#status !== 'created') {
      throw new SessionStateError(
        'already_started',
        `session ${this.sessionId} is already started`,
      );
    }
    this.#status = 'idle';
    this.#deps.emit({
      type: 'session:started',
      agentRef: this.#agentRef,
      model: this.#agent.model,
      context: this.#context,
    });
  }

  /**
   * Set (or clear) the **reseat-less mode policy** (ADR-0057) — the advertise-filter + the interactive
   * approval hook — on this SAME session instance. The host calls it when its mode changes (e.g. `Shift+Tab`);
   * the change is **lossless** (no reseat, no tool-context loss) and applies on the **next** turn (each
   * `sendMessage` snapshots the policy at turn start). Pass `undefined` to clear it (back to advertise-all /
   * no-approval-regime). Callable in **any** state, including mid-turn (it takes effect next turn); it is
   * **inert once `cancelled`** (a cancelled session runs no further turn, so the policy is never read again).
   */
  setTurnPolicy(policy: SessionTurnPolicy | undefined): void {
    this.#turnPolicy = policy;
  }

  /**
   * Set (or clear) the **session-level reasoning-effort override** ([ADR-0066](../../../../docs/decisions/0066-normalized-reasoning-effort-control.md) §5)
   * on this SAME session instance — the interactive `/models` effort sub-step + a `/effort` command call it. The
   * change is **lossless** (no reseat, no tool/reasoning-context loss — effort changes neither the provider, the
   * pricing, nor the memoized `#plan`) and applies on the **next** turn (each `sendMessage` reads the override at
   * turn start). Pass `undefined` to clear it (fall back to the agent's authored `reasoning_effort`). Callable in
   * **any** state incl. mid-turn (takes effect next turn); **inert once `cancelled`** (no further turn reads it).
   * The tier is still gated per turn against the tiers the bound model accepts ({@link SessionDeps.resolveEffortTiers}),
   * so a tier the model does not take is withheld at send — and {@link SessionDeps.onEffortWithheld} says so, rather
   * than leaving the user to wonder why the knob did nothing.
   */
  setReasoningEffort(effort: ReasoningEffort | undefined): void {
    this.#reasoningEffort = effort;
  }

  /**
   * The session's EFFECTIVE reasoning-effort tier ([ADR-0066](../../../../docs/decisions/0066-normalized-reasoning-effort-control.md) §5)
   * — the session override, else the agent's authored `reasoning_effort`, else `undefined`. This is the resolved
   * tier BEFORE the per-model capability gate ({@link gateReasoningEffort}); a surface reads it to show the active
   * tier (a footer indicator, the `/models` effort sub-list's ✓/highlight) without having to track it itself.
   */
  get reasoningEffort(): ReasoningEffort | undefined {
    return this.#reasoningEffort ?? this.#agent.reasoning_effort;
  }

  /** Guard the send preconditions: the session must be started and idle (not running/cancelled/ended). */
  #assertSendable(): void {
    if (this.#status === 'created') {
      throw new SessionStateError('not_started', `session ${this.sessionId}: call start() first`);
    }
    if (this.#status !== 'idle') {
      throw new SessionStateError(
        'not_active',
        `session ${this.sessionId} is ${this.#status}; cannot send a message`,
      );
    }
  }

  /**
   * Run one user turn end to end: append the user message, drive the turn core (streaming + tool loop +
   * fallback), append the assistant reply, and emit `session:turn_started` → `session:turn_completed`.
   * A turn past the hard cap is blocked **loudly** with `turn_limit` and **no egress**. A classified
   * turn failure still **completes** — with `stopReason: 'error'` and the mapped error code. Resolves
   * when the turn settles; a cancel mid-turn resolves quietly (the terminal is `session:cancelled`).
   */
  async sendMessage(text: string): Promise<void> {
    this.#assertSendable();

    // Clear any stale EA7 abort marker BEFORE arming the turn, so an `abort()` a prior turn's synchronous
    // turn_started-emit sink set (which then took a pre-`try` early return, bypassing the `finally` reset)
    // can never leak into this turn's catch path and misclassify a real failure as an abort.
    this.#abortingTurn = false;
    this.#status = 'running';
    // Arm the abort controller BEFORE the turn_started emit. A host whose sink calls abort() synchronously
    // inside that emit must abort THIS turn's real signal — if #abort were still undefined, abort()'s
    // `#abort?.abort()` would be a no-op while still setting #abortingTurn, and a later GENUINE failure would
    // then be misclassified as `aborted`. The cancel-bail + cap block release it on their early returns.
    const abort = this.#deps.newAbortController();
    this.#abort = abort;
    this.#deps.emit({ type: 'session:turn_started' });
    // A cancel can fire SYNCHRONOUSLY inside the turn_started emit (a host whose sink calls cancel()). If it
    // did, session:cancelled is the terminal — bail before the cap block and before any egress, else we would
    // overwrite the 'cancelled' status back to 'idle' and emit a second terminal, or silently egress an
    // already-cancelled turn. (cancel() already cleared #abort.)
    if (this.#statusIs('cancelled')) return;

    // Hard turn cap — checked AFTER turn_started (the turn was attempted) but BEFORE any egress: the
    // blocked turn completes loudly with turn_limit and never calls a provider.
    if (this.#completeIfTurnCapReached()) return;

    this.#messages.push({ role: 'user', content: [{ type: 'text', text }] });
    // Snapshot the reseat-less mode policy for the whole turn (ADR-0057): a mid-turn setTurnPolicy applies
    // only on the NEXT turn, so the advertise-filter + approval regime stay consistent within this turn.
    const turnPolicy = this.#turnPolicy;
    try {
      this.#lastEngagedUsage = undefined; // never inherit an earlier turn's numbers
      const result = await this.#runTurn(abort.signal, turnPolicy);
      // A cancel landed mid-turn — the cancel path owns the terminal session:cancelled; stay quiet, but
      // roll the user message back so a cancelled turn leaves no dangling user turn in the transcript
      // (the "only completed exchanges" invariant — matters for 1.X persistence / 1.Z export).
      if (this.#statusIs('cancelled')) {
        this.#messages.pop();
        return;
      }
      // EA7 note: an `abort()` that lands AFTER the turn fully resolved (a late `Esc`, past the turn core's
      // last `throwIfAborted`) is a no-op — the turn already produced its reply, so it completes NORMALLY
      // (the reply is kept, the turn is counted). `abort()` interrupts an IN-FLIGHT turn only; a turn the
      // model already finished is not discarded. This success path **never reads `#abortingTurn`** — that is
      // precisely what makes a late abort structurally invisible here; the `finally` still clears the marker.
      // Counted HERE, BEFORE the durability flush below, and that ordering is a decision rather than an
      // accident (`CR-02`). The rule both catch paths already apply is *count a turn against the hard cap
      // only when a provider actually ENGAGED* — and by this line `#runTurn` has resolved, so one did. A
      // `flushBudgetCommitments` rejection past this point is a durability failure, not evidence the turn
      // never happened; moving the increment below the flush would hand back a turn the provider billed.
      // Pinned by "a turn whose durability flush REJECTS still consumes its slot against the cap".
      this.#turnCount += 1;
      // Append the assistant reply to the cross-turn transcript as TEXT-ONLY. The turn core keeps the
      // within-turn tool_use/tool_result pairs internal (they never leave runAgentTurn — it returns only the
      // final, non-tool_use content), so the transcript carries no orphaned tool_use and stays protocol-valid
      // across turns. Reasoning parts are dropped here on purpose: a reasoning `signature` is a within-turn,
      // same-provider replay token (ADR-0030/0039) and must NOT span turns — a turn that failed over would
      // otherwise carry a fallback-provider signature into the next turn's primary request. Faithful
      // cross-turn tool/reasoning history is the 1.X/1.Z deferral (it needs the turn core to expose the
      // intermediate messages, which the concurrent 1.AC work currently owns in agent-turn.ts).
      // ADR-0074 §2: the enclosing turn completion WAITS for the commitment's durability acknowledgement.
      // Before this, a chat reported a turn complete — `sendMessage` returned, the process could exit — while
      // the commitment for a possibly-billed call had not reached the database. A failure here fails THIS turn,
      // which is the point: §2 says a durability failure fails the active owner loudly, and surfacing it on some
      // later unrelated turn is exactly the misattribution the barrier exists to prevent.
      //
      // Only the SUCCESS path awaits it this way. An abort or a classified turn error already carries its own
      // terminal, and replacing a `provider_auth` failure with a durability failure would hide the cause the
      // user needs; the governor keeps the debit and its sticky `conservativeDurabilityBroken` regardless.
      //
      // It runs BEFORE the assistant append below, not after. The catch's rollback pops exactly ONE message
      // and its comment relies on "nothing is pushed after the user message on a throw" — which stopped being
      // true when this await landed between them: a flush rejection popped the ASSISTANT message and left the
      // user turn dangling, the exact shape that rollback exists to prevent. Awaiting first restores it.
      // Captured BEFORE the flush, so a rejection below still knows what the provider billed (`CR-02`).
      this.#lastEngagedUsage = { input: result.usage.input, output: result.usage.output };
      await this.#deps.flushBudgetCommitments?.();
      if (result.text.length > 0) {
        this.#messages.push({ role: 'assistant', content: [{ type: 'text', text: result.text }] });
      }
      this.#emitTurnCompleted(result.stopReason, {
        input: result.usage.input,
        output: result.usage.output,
        model: result.model,
      });
      // ADR-0062: arm the after-turn auto-compaction check for AFTER this turn fully settles (status back to
      // idle in the `finally`). Set ONLY on this clean-success path — never on an error/abort/cancel/cap exit
      // (those return before here or from the catch, so a failed turn never triggers compaction).
      this.#autoCompactPending = { model: result.model, inputTokens: result.usage.input };
    } catch (err) {
      // The turn did not complete — roll the user message back so the transcript holds only COMPLETED
      // exchanges (no dangling user turn or two consecutive user messages) on EVERY non-completing exit,
      // including a cancel-during-turn. Nothing is pushed after the user message on a throw (the assistant
      // append is past the `await`), so the last element is always that message. This also keeps a
      // non-AgentTurnError from orphaning it — a pre-egress `BudgetPauseError` is settled loudly as
      // `budget_exceeded` by `#settleTurnError` below (a session has no pause/resume gate machinery), and an
      // unclassified throw is settled and re-raised.
      this.#messages.pop();
      if (this.#statusIs('cancelled')) return; // cancel-during-turn: session:cancelled is the terminal
      if (this.#abortingTurn) {
        // EA7 mid-turn abort: the turn core threw on the aborted signal (an AgentTurnError 'cancelled').
        // Settle as ONE `session:turn_completed{stopReason:'aborted'}` — NO error (user-initiated, not a
        // failure) — and keep the session alive; the `finally` returns #status to idle. Count the turn
        // against the hard cap only when a provider engaged + report its real EA2 usage (consistent with
        // #settleTurnError). It is NOT `cancel()`/`session:cancelled` (which is terminal).
        const aborted = err instanceof AgentTurnError ? err : undefined;
        if (aborted?.engaged === true) this.#turnCount += 1;
        this.#emitTurnCompleted('aborted', aborted?.usage ?? { input: 0, output: 0 });
        return;
      }
      this.#settleTurnError(err); // emits the terminal by error class; RE-THROWS an unclassified error
    } finally {
      this.#abort = undefined;
      this.#abortingTurn = false; // clear the per-turn EA7 marker (no stale abort leaks into the next turn)
      if (this.#statusIs('running')) this.#status = 'idle';
    }
    // ADR-0062: run the after-turn auto-compaction check AFTER the turn has fully settled (status is now idle).
    // Only the clean-success path armed `#autoCompactPending`; every non-completing exit returned earlier, so
    // this line is unreachable on an error/abort/cancel/cap turn. Runs within `sendMessage`, so the host's
    // "turn running" indicator naturally covers the summarisation moment and the caller awaits it.
    const pending = this.#autoCompactPending;
    this.#autoCompactPending = undefined;
    if (pending !== undefined) await this.#maybeAutoCompact(pending.model, pending.inputTokens);
  }

  /**
   * The hard turn-cap gate, factored out of {@link sendMessage}. When the session has already spent its
   * `#maxTurns`, complete the just-armed turn LOUDLY with `turn_limit` and no egress, release the armed abort
   * controller (this path is an early return that skips `sendMessage`'s `finally`), and return `true` so the
   * caller bails before touching a provider. Returns `false` (turn may proceed) when under the cap.
   */
  #completeIfTurnCapReached(): boolean {
    if (this.#turnCount < this.#maxTurns) return false;
    this.#status = 'idle';
    this.#abort = undefined; // no turn ran — release the armed controller (this early return skips finally)
    this.#emitTurnCompleted(
      'error',
      { input: 0, output: 0 },
      {
        code: 'turn_limit',
        message: `session reached its hard cap of ${this.#maxTurns} turns`,
        retryable: false,
      },
    );
    return true;
  }

  /**
   * Settle a turn that ended in a throw onto a terminal `session:turn_completed`, by error class. The caller has
   * already rolled the user message back and ruled out a cancel-during-turn.
   * - A classified {@link AgentTurnError} completes with its mapped code, counting the turn against the cap ONLY
   *   when a provider engaged (see {@link AgentTurnError.engaged}) and reporting its real EA2 usage.
   * - A pre-egress {@link BudgetPauseError} completes as `budget_exceeded` (it engaged no provider → uncounted).
   * - Any other (unclassified) error completes as `internal` and is **re-thrown** so the caller still sees the bug.
   */
  #settleTurnError(err: unknown): void {
    if (err instanceof AgentTurnError) {
      // Count the turn against the cap ONLY when a provider actually engaged (a non-skipped attempt ran — an
      // explicit signal the turn core attaches). A failure BEFORE any egress (no plan entries, a pre-egress
      // budget refusal, a pre-flight cancel) must not burn a turn the model never got to take; `engaged !== true`
      // (covering an undefined from an error that bypassed the wrapper) leaves the counter untouched.
      if (err.engaged === true) this.#turnCount += 1;
      // EA2 (ADR-0055): report the turn's REAL accumulated usage when a provider engaged (the turn core attaches
      // it), not a hardcoded zero — `?? {0,0}` covers a failure that never engaged a provider.
      this.#emitTurnCompleted('error', err.usage ?? { input: 0, output: 0 }, {
        code: err.code,
        message: err.message,
        retryable: err.retryable,
      });
      return;
    }
    if (err instanceof BudgetPauseError) {
      // A session has no pause/resume gate machinery in 1.V (full session pause/resume is a deferred 1.V×1.AC
      // item), so a pre-egress `pause_for_approval` settles the turn LOUDLY as `budget_exceeded` rather than
      // escaping `sendMessage` as a raw throw — which would leave the turn with no terminal, breaking the M1
      // event contract. It engaged NO provider (the pause is pre-egress), so it does NOT count.
      this.#emitTurnCompleted(
        'error',
        { input: 0, output: 0 },
        { code: 'budget_exceeded', message: err.message, retryable: false },
      );
      return;
    }
    // An unexpected (non-classified) error — settle the turn LOUDLY first so the stream stays balanced (every
    // session:turn_started gets a terminal), then re-raise so the caller still sees the bug.
    //
    // `#lastEngagedUsage`, not a hardcoded zero (`CR-02`). The only unclassified error that reaches here in
    // practice is a `flushBudgetCommitments` rejection — a turn whose provider ALREADY engaged and billed,
    // which is exactly why the same decision counts it against the cap. Reporting `{0,0}` here consumed the
    // cap slot and silently dropped the turn's real tokens from every total, which is the mirror of the error
    // the counter decision refuses to make, and contradicts EA2/ADR-0055's rule to report real usage whenever
    // a provider engaged. Falls back to zero when nothing engaged, which stays truthful.
    this.#emitTurnCompleted('error', this.#lastEngagedUsage ?? { input: 0, output: 0 }, {
      code: 'internal',
      message: 'the session turn failed with an unexpected error',
      retryable: false,
    });
    throw err;
  }

  /**
   * Read the current status WITHOUT control-flow narrowing — `#status` can change across an `await` in
   * {@link sendMessage} (a {@link cancel} fired from the emit sink), which TS cannot model after the literal
   * `this.#status = 'running'` assignment. Routing post-await reads through a call keeps them sound.
   */
  #statusIs(status: SessionStatus): boolean {
    return this.#status === status;
  }

  /** Abort an in-flight turn (if any) and end the session, emitting `session:cancelled`. Idempotent. */
  cancel(): void {
    if (this.#status === 'cancelled') return;
    this.#status = 'cancelled';
    this.#abort?.abort();
    this.#abort = undefined;
    this.#deps.emit({ type: 'session:cancelled' });
  }

  /**
   * **Mid-turn abort** (ADR-0057 EA7) — `Esc` ends the *in-flight turn* but **keeps the session alive**
   * (unlike {@link cancel}, which is terminal). It aborts the turn's signal; the turn core then throws on
   * the abort and the `sendMessage` catch settles the turn as **one** `session:turn_completed{stopReason:
   * 'aborted'}` (no `error` — it is user-initiated, not a failure), rolls the pending user message back, and
   * returns `#status` to `idle` so the next `sendMessage` continues the conversation. A **late** abort that
   * lands after the turn already RESOLVED is a no-op — that turn completes normally (its reply is kept), so
   * a just-finished reply is never discarded. No-op unless a turn is in flight (`running`); a `cancel()`
   * already in progress wins (terminal precedence). There is **no** new session status.
   */
  abort(): void {
    if (this.#status !== 'running') return; // nothing in flight (or already terminal) — nothing to abort
    this.#abortingTurn = true;
    this.#abort?.abort();
  }

  /**
   * Build the per-dispatch {@link ToolDispatchContext} (sans `signal`) shared by {@link #runTurn} and the
   * {@link runUserCommand} `!`-shell path ([ADR-0061](../decisions/0061-cli-input-layer-file-injection-and-shell-escape.md)):
   * the granted set, the session `toolPolicy` (the `allowedCommands` allowlist), the `fsScope`, `gateApproved:
   * false`, and — under a set mode policy (ADR-0057) — the interactive-approval regime (`confirm` + the EA5
   * `agent:approval_requested` emit). Factored so the `!`-shell reuses the SAME regime VERBATIM rather than a
   * dispatch context re-assembled in `apps/cli` (the one command boundary, never a fork).
   */
  #buildDispatchContext(
    grantedToolIds: ReadonlySet<ToolId>,
    turnPolicy: SessionTurnPolicy | undefined,
  ): Omit<ToolDispatchContext, 'signal'> {
    return {
      // The SESSION correlation — `{ kind: 'session', sessionId, turn }`, which this path can supply without
      // fabricating anything. ADR-0024 gives a session no `runId`, and the discriminated union is exactly why
      // it never has to invent one. The turn count is the session's own durable counter, restored on resume.
      // The SESSION correlation, stamped with THIS turn. `#turnCount` is the session's own durable counter,
      // restored on resume, so a resumed session continues its numbering instead of colliding with the turns
      // it already ran.
      effects:
        this.#deps.effects?.({
          kind: 'session',
          sessionId: this.sessionId,
          turn: this.#turnCount,
        }) ?? unwiredEffectJournal(),
      effectSlot: 0, // per-CALL; the dispatch sites override it with the tool call's ordinal
      nodeId: this.#agentRef,
      grantedToolIds,
      config: {}, // an agent-invoked tool carries no per-tool config block in v1.0
      toolPolicy: this.#deps.toolPolicy ?? {},
      fsScope: this.#context.fsScopeTier,
      gateApproved: false, // a chat loop provides no human gate — git_commit stays denied (parity with 1.O)
      // ADR-0057: a set mode policy ACTIVATES the interactive-approval regime — a governed (write/process/
      // egress) dispatch then requires the host's `confirm` decision, fail-closed when `confirm` is absent
      // (`approval: {}`). No policy ⇒ no `approval` key ⇒ the workflow author-trust floor, unchanged.
      ...(turnPolicy === undefined
        ? {}
        : {
            // No confirm hook ⇒ `approval: {}` (the fail-closed floor — a governed dispatch is denied with
            // no_approval_hook, before any emit). WITH a hook, also wire EA5: the engine emits
            // `agent:approval_requested` (stamping this turn's nodeId) through the same session sink the in-turn
            // bodies use, just before the host's confirm hook prompts — a durable observability trace of the
            // pending decision on the session / `--json` stream (ADR-0057).
            approval:
              turnPolicy.confirm === undefined
                ? {}
                : {
                    confirm: turnPolicy.confirm,
                    emitApprovalRequested: (request) => {
                      this.#deps.emit({
                        type: 'agent:approval_requested',
                        nodeId: this.#agentRef,
                        toolId: request.toolId,
                        action: request.action,
                        preview: request.preview,
                      });
                    },
                  },
          }),
    };
  }

  /**
   * Run a USER-invoked `!`-shell command (2.5.D, [ADR-0061](../decisions/0061-cli-input-layer-file-injection-and-shell-escape.md))
   * — the additive engine method that routes the shell escape through the ONE `run_command` boundary:
   * `enforcePolicy(allowedCommands)` (the exact-match allowlist, enforced BEFORE approval) → the mode-aware
   * `confirmAction` gate → the hardened process arm (`spawn`, `shell:false`). It reuses {@link #runTurn}'s
   * dispatch-context construction VERBATIM (`this.#turnPolicy`, the session `toolPolicy`, `fsScope`,
   * `gateApproved: false`), so the `!`-shell can never diverge from the audited command sandbox. The caller
   * pre-tokenizes the line into `command` + `args` (no shell metachar expansion). The classified result is a
   * discriminated union — the host renders the output (untrusted context), the actionable allowlist-deny hint, or
   * a failure — so no raw error escapes. Callable only when the session is started + idle (a `!` never races a turn).
   */
  async runUserCommand(command: string, args: readonly string[]): Promise<UserCommandOutcome> {
    this.#assertSendable(); // started + idle — a `!` never runs concurrently with a model turn
    this.#status = 'running';
    const abort = this.#deps.newAbortController();
    this.#abort = abort; // so cancel()/abort() can interrupt a long-running command
    this.#userCommandSeq += 1; // a fresh synthetic tool-call id per `!`-command
    const toolCall: ToolCallPart = {
      type: 'tool_call',
      id: `usercmd-${this.#userCommandSeq}`,
      name: 'run_command',
      args: { command, args: [...args] },
    };
    try {
      // The user-initiated `!` GRANTS `run_command` for THIS one-off dispatch (the user typed it — the grant is
      // implicit), regardless of whether the bound agent lists it in `tools`. This never reaches the model: it is a
      // direct dispatch, not a turn, so the model's granted/advertised set is untouched. The security gate stays the
      // allowlist (`enforcePolicy`, BEFORE approval) + the mode-aware `confirmAction`, never this grant.
      const grantedToolIds = new Set<ToolId>([...(this.#agent.tools ?? []), 'run_command']);
      const outcome = await this.#deps.registry.dispatch(toolCall, {
        ...this.#buildDispatchContext(grantedToolIds, this.#turnPolicy),
        // The `!`-command sequence IS the effect slot here (ADR-0080). Slot 0 would be wrong: two `!`
        // commands within one turn share a correlation, so they would collide on the journal's UNIQUE
        // identity and the second would be refused as a duplicate of the first. The counter already exists
        // for the synthetic tool-call id and is exactly the per-command ordinal the slot wants.
        // **A DISJOINT slot space from the model's, and negative for exactly that reason.** A `!`-command and
        // a model tool call live in the same correlation, so a shared ordinal collides them: `!`-command 1
        // and the model's second tool call of that turn would both be slot 1 on the journal's UNIQUE
        // identity, and the second to arrive would be refused as a duplicate of an unrelated effect.
        // Negative ordinals cannot meet the model's non-negative ones, whatever either counter does.
        effectSlot: -this.#userCommandSeq,
        signal: abort.signal,
      });
      const result = outcome.output;
      if (!isProcessResult(result)) {
        return { kind: 'failed', message: 'run_command returned an unexpected result shape' };
      }
      // Return the process-arm–bounded stdout/stderr (the identity `output`, no `outputMapping`). NOT
      // `outcome.truncated` — that flag comes from the SEPARATE model-facing `boundForModel` pass whose bounded
      // value is discarded here, so it would describe data the caller never receives. The host re-bounds on inject.
      return {
        kind: 'ran',
        exitCode: result.exitCode,
        stdout: result.stdout,
        stderr: result.stderr,
      };
    } catch (err) {
      if (err instanceof ToolCancelledError) return { kind: 'cancelled' };
      // An allowlist MISS is a policy denial with `command_not_allowed` — the host shows the actionable
      // `[chat].allowed_commands` hint; any other `tool_denied` (an approval reject / protected path) is a plain
      // decline. Both messages are secret-free (the error classes never echo the resolved command value).
      if (err instanceof ToolPolicyError) {
        return {
          kind: 'denied',
          allowlist: err.reason === 'command_not_allowed',
          message: err.message,
        };
      }
      if (err instanceof ToolDeniedByUserError) {
        return { kind: 'denied', allowlist: false, message: err.message };
      }
      if (err instanceof ToolDispatchError) return { kind: 'failed', message: err.message };
      throw err; // an unexpected non-tool error (a wiring bug) — surface loudly, never swallow
    } finally {
      this.#abort = undefined;
      this.#abortingTurn = false; // an Esc-abort during the command set this marker — clear it (mirrors sendMessage)
      if (this.#status === 'running') this.#status = 'idle'; // a cancel() may have set 'cancelled' — don't revert it
    }
  }

  /**
   * The per-turn system prompt: the agent's authored `system_prompt`, and nothing else.
   *
   * It used to concatenate the compaction summary here, XML-wrapped
   * ([ADR-0062](../../../../docs/decisions/0062-context-compaction-and-cli-history-commands.md) §1). That is
   * the defect ADR-0081 removes: the summary is model output over untrusted input, an XML fence is not a
   * trust boundary, and the bytes survived a restart because the summary is persisted. The summary now goes
   * through {@link buildTurnMessages} into a user-role part, and the branded return type is what keeps a
   * dynamic string from reaching this field again.
   */
  #systemPrompt(): AuthoredSystemPrompt {
    return authoredSystemPrompt({ kind: 'agent', agent: this.#agent });
  }

  /** The messages for one request — the transcript with the summary projected in (ADR-0081 §3). */
  #turnMessages(): LlmMessage[] {
    return buildTurnMessages(this.#compactionSummary, this.#messages);
  }

  /**
   * **Compact the working context** (ADR-0062, `/compact` + the auto-threshold path) — summarise the earlier
   * conversation into the {@link #compactionSummary} via the session's OWN bound model, keep the last complete
   * `user`+`assistant` exchange verbatim, and emit `session:compacted`. Append-only at the durable layer: the
   * host writes a boundary marker on the event; the engine mutates only in-memory state. Callable only when
   * started + idle. Aborting mid-summary (`cancel`/`abort`) yields `cancelled` and leaves the context
   * unchanged. The summarisation's cost is accounted via `cost:updated` (the session budget), but its
   * `agent:token`/tool events are NOT forwarded — the summary is internal context, never a transcript reply.
   */
  async compact(reason: 'manual' | 'auto-threshold' = 'manual'): Promise<CompactionResult> {
    this.#assertSendable();
    const split = splitFoldable(this.#messages);
    if (split === undefined) return { kind: 'nothing_to_compact' }; // ≤1 exchange — nothing to fold
    const plan = this.#resolvePlan();
    if (!plan.ok) return { kind: 'failed', message: plan.message };

    this.#status = 'running';
    const abort = this.#deps.newAbortController();
    this.#abort = abort;
    try {
      // Announce the compaction MOMENT (ADR-0062 §7) — emitted AFTER the nothing-to-fold / plan-resolution guards
      // (so a no-op never flashes the indicator) so the host can drive a labeled "Summarizing…" indicator while the
      // summariser LLM call runs, for both a manual `/compact` and an auto-threshold trigger. The terminal
      // `session:compacted` (success) / `session:trimmed` auto-fallback (failure→trim) ends the moment; a manual
      // failure emits no terminal, so the manual host clears the moment when `compact()` resolves. Inside the `try`
      // (like the estimate below) so nothing escapes past the `finally` that resets `#status`.
      this.#deps.emit({ type: 'session:compacting', reason });
      // Inside the `try` so a provider whose optional `estimateTokens` throws cannot escape past the `finally`
      // and leave `#status` wedged at 'running' (the seam method is provider-supplied).
      const tokensBefore = this.#estimateContextTokens();
      const result = await runAgentTurn({
        system: authoredSystemPrompt({ kind: 'engine', prompt: 'compaction' }),
        messages: [renderConversationToSummarise(this.#compactionSummary, split.foldable)],
        planEntries: plan.entries,
        chainCapabilities: this.#chainCapabilities(),
        nodeId: this.#agentRef,
        maxTokens: COMPACTION_MAX_SUMMARY_TOKENS, // bound the summary so compaction reliably reduces context
        // Forward ONLY cost:updated (budget accounting, ADR-0028) — drop agent:token/tool events so the
        // internal summary never streams into the chat transcript as a reply.
        emit: (event) => {
          if (event.type === 'cost:updated') this.#onTurnEmit(event);
        },
        // Compaction drops every streaming event except `cost:updated`, so this turn cannot flood a
        // consumer — the await is wired anyway so the two turn sites cannot drift, and it costs one
        // already-resolved microtask per chunk.
        ...(this.#deps.whenReady === undefined ? {} : { whenReady: this.#deps.whenReady }),
        signal: abort.signal,
        registry: this.#deps.registry,
        dispatchContext: this.#buildDispatchContext(new Set(), undefined),
        limits: this.#limits,
        ...(this.#deps.preEgress === undefined ? {} : { preEgress: this.#deps.preEgress }),
        ...(this.#deps.resolvePrice === undefined ? {} : { resolvePrice: this.#deps.resolvePrice }),
      });
      const summary = result.text.trim();
      if (summary.length === 0) {
        // The model returned no summary text — treat as a failure (the caller degrades to /trim) rather than
        // installing an empty preamble that would silently lose the folded context.
        return { kind: 'failed', message: 'the summarisation produced no summary text' };
      }
      // **Marked here, at the moment it leaves the model.** Everything downstream — persistence, resume,
      // reseat, the request projection — carries the brand, so a future call site cannot put it somewhere
      // it does not belong without unwrapping it and saying so.
      this.#compactionSummary = markUntrusted(summary);
      this.#messages.length = 0;
      this.#messages.push(...split.kept);
      const tokensAfter = this.#estimateContextTokens();
      this.#deps.emit({
        type: 'session:compacted',
        reason,
        summary,
        keptMessageCount: split.kept.length,
        tokensBefore,
        tokensAfter,
        tokensUsed: { input: result.usage.input, output: result.usage.output },
      });
      return {
        kind: 'compacted',
        reason,
        summary,
        keptMessageCount: split.kept.length,
        tokensBefore,
        tokensAfter,
        summaryTokens: { input: result.usage.input, output: result.usage.output },
      };
    } catch (err) {
      return this.#classifyCompactionError(err); // may re-throw an unclassified error (surfaced loudly)
    } finally {
      this.#abort = undefined;
      this.#abortingTurn = false;
      if (this.#statusIs('running')) this.#status = 'idle';
    }
  }

  /**
   * Map a caught {@link compact} error to a {@link CompactionResult} (factored out to keep `compact` focused on
   * the happy path, mirroring {@link #settleTurnError}). A cancel/abort (terminal `cancel()`, `ToolCancelledError`,
   * an EA7 `Esc`, or a classified `cancelled`) ⇒ `cancelled`; a classified {@link AgentTurnError} or a pre-egress
   * {@link BudgetPauseError} ⇒ `failed` (the caller degrades to `/trim`); a truly UNCLASSIFIED error is a bug and
   * is RE-THROWN so it surfaces loudly (never silently masked as an ordinary `failed`).
   */
  #classifyCompactionError(err: unknown): CompactionResult {
    if (this.#statusIs('cancelled') || err instanceof ToolCancelledError || this.#abortingTurn) {
      return { kind: 'cancelled' };
    }
    if (err instanceof AgentTurnError) {
      return err.code === 'cancelled'
        ? { kind: 'cancelled' }
        : { kind: 'failed', message: err.message };
    }
    if (err instanceof BudgetPauseError) return { kind: 'failed', message: err.message };
    throw err;
  }

  /**
   * **Deterministically trim history** to the last `maxMessages` messages (ADR-0062, `/trim`) — NO LLM call,
   * no cost. The kept slice is snapped to start on a `user` message (an orphan leading `assistant` is dropped)
   * so the next turn stays protocol-valid. Leaves {@link #compactionSummary} untouched (a trim drops older turns
   * without summarising — a prior `/compact` summary survives). Emits `session:trimmed`; the host writes a
   * summary-less boundary marker. Callable only when started + idle.
   */
  trimHistory(maxMessages: number, reason: 'manual' | 'auto-fallback' = 'manual'): TrimResult {
    this.#assertSendable();
    const kept = tailFromUserBoundary(this.#messages, maxMessages);
    const dropped = this.#messages.length - kept.length;
    if (dropped <= 0) return { kind: 'nothing_to_trim', messageCount: this.#messages.length };
    this.#messages.length = 0;
    this.#messages.push(...kept);
    this.#deps.emit({
      type: 'session:trimmed',
      reason, // `auto-fallback` when the auto-compaction summariser failed → the view surfaces it (never silent)
      keptMessageCount: kept.length,
      droppedMessageCount: dropped,
    });
    return { kind: 'trimmed', keptMessageCount: kept.length, droppedMessageCount: dropped };
  }

  /**
   * The after-turn auto-compaction gate (ADR-0062) — run from {@link sendMessage} AFTER a clean turn settles.
   * Compacts when: auto-compaction is enabled; the SERVING model's context window is known; the turn's real
   * input tokens exceed `threshold × window`; and there is more than one exchange to fold. Skips a provider
   * that manages its own context. On a summarisation failure it degrades to a deterministic `/trim` to
   * `maxMessages` (zero cost) rather than sending an ever-growing context. A no-op on every skip condition.
   */
  async #maybeAutoCompact(model: string, inputTokens: number): Promise<void> {
    if (this.#deps.autoCompact === false) return;
    if (this.#status !== 'idle') return; // a cancel/abort landed after the turn — do not compact
    const plan = this.#resolvePlan();
    if (!plan.ok) return;
    // Consult the SERVING provider (the plan entry whose model actually produced this turn under fallback), not
    // just the primary — so managesOwnContext / contextLimit reflect the model that would overflow NEXT. Both are
    // OPTIONAL, provider-supplied seam methods; a throw from either must be a non-fatal SKIP (auto-compaction is
    // best-effort) — never escape and reject `sendMessage` after the turn already completed (mirrors #estimateTokens).
    let window: number | undefined;
    try {
      const serving =
        plan.entries.find((entry) => entry.model === model)?.provider ?? plan.entries[0]?.provider;
      if (serving?.managesOwnContext?.() === true) return; // the provider bounds context itself
      window = serving?.contextLimit?.(model);
    } catch {
      return; // a throwing provider seam method → skip auto-compaction, don't crash the settled turn
    }
    if (window === undefined || window <= 0) return; // unrated/custom model — window unknown, skip auto-compaction
    const budget = window * (this.#deps.compactThreshold ?? DEFAULT_COMPACT_THRESHOLD);
    if (inputTokens <= budget) return; // under the trigger — nothing to do
    const split = splitFoldable(this.#messages);
    if (split === undefined) return; // ≤1 exchange — nothing earlier to fold (thrash guard a)
    // ADR §5 thrash guard b: estimate the PROJECTED post-compaction floor — the BASE system prompt (NOT the
    // current preamble, which the new summary REPLACES) + the kept exchange + the bounded summary the
    // compaction will produce (`COMPACTION_MAX_SUMMARY_TOKENS`). If even that floor exceeds the budget,
    // compaction cannot help (a single oversized turn / a huge system prompt) — skip and let the overflow
    // surface via the error taxonomy, rather than paying a summariser call on every subsequent turn.
    const projectedFloor =
      this.#estimateTokens(this.#agent.system_prompt, split.kept) + COMPACTION_MAX_SUMMARY_TOKENS;
    if (projectedFloor > budget) return;

    let result: CompactionResult;
    try {
      result = await this.compact('auto-threshold');
    } catch {
      // `compact()` RE-THROWS an UNCLASSIFIED error (a bug) rather than returning `{kind:'failed'}`. Auto-compaction
      // is BEST-EFFORT and runs AFTER the turn already completed (session:turn_completed emitted), so such a throw
      // must NOT reject an otherwise-successful `sendMessage` — mirror the seam-method guard above. Treat it as a
      // failure so the deterministic /trim fallback below still bounds the next turn (ADR §5).
      result = { kind: 'failed', message: 'auto-compaction summariser threw' };
    }
    // Degrade a non-success — a `failed` summariser OR an EA7-aborted `cancelled` — to a deterministic, zero-cost
    // /trim so the next turn is bounded (never a silent overflowing resend, ADR §5). A terminal `cancel()` leaves
    // status !== 'idle', so this guard skips a dead session; a `compacted`/`nothing_to_compact` needs no fallback.
    if (
      (result.kind === 'failed' || result.kind === 'cancelled') &&
      this.#deps.maxMessages !== undefined &&
      this.#status === 'idle'
    ) {
      this.trimHistory(this.#deps.maxMessages, 'auto-fallback');
    }
  }

  /** A rough token estimate of the current working context (system-with-preamble + messages) — for the
   *  before/after deltas on `session:compacted`. Best-effort; 0 if absent. */
  #estimateContextTokens(): number {
    // The same projection the request uses — an estimator measuring a different array than the request is
    // how a context-window guard drifts from the thing it is guarding.
    return this.#estimateTokens(this.#systemPrompt(), this.#turnMessages());
  }

  /**
   * Estimate the tokens of `system + messages` via the primary provider's optional seam estimator
   * (provider-agnostic in practice). Best-effort and **never throws** — a provider-supplied `estimateTokens`
   * that throws is swallowed to 0, so an estimate can never wedge `#status`, escape `compact()`'s `finally`,
   * or crash the auto-compaction gate (the value only drives an observability delta / a thrash heuristic).
   */
  #estimateTokens(system: string, messages: readonly LlmMessage[]): number {
    const plan = this.#resolvePlan();
    if (!plan.ok) return 0;
    try {
      // Call inline (not via an extracted method reference) so `estimateTokens` stays bound to its provider.
      return plan.entries[0]?.provider.estimateTokens?.({ system, messages }) ?? 0;
    } catch {
      return 0; // a best-effort estimate — never let a throwing seam estimator break compaction
    }
  }

  /** Build (memoized) the fallback plan and drive one turn through the shared core. */
  async #runTurn(
    signal: AbortSignalLike,
    turnPolicy: SessionTurnPolicy | undefined,
  ): Promise<AgentTurnResult> {
    const plan = this.#resolvePlan();
    if (!plan.ok) {
      // A host-wiring gap (a provider was not resolved) — a classified, non-retryable internal failure.
      throw new AgentTurnError('internal', plan.message, false);
    }
    const grantedToolIds = new Set(this.#agent.tools ?? []);
    const dispatchContext = this.#buildDispatchContext(grantedToolIds, turnPolicy);
    // Advertise-filter (ADR-0057): narrow the model-visible tool set per the host's mode (best-effort; the
    // confirm floor stays authoritative). No policy / no filter ⇒ advertise every granted tool.
    const llmTools = buildLlmTools(
      this.#deps.tools,
      grantedToolIds,
      dispatchContext,
      turnPolicy?.advertise,
    );
    // ADR-0066/0071: resolve the effective reasoning-effort tier (session override → agent's authored tier) and
    // gate it on WHICH TIERS the bound model accepts. Read at turn start so a mid-session setReasoningEffort
    // applies to the NEXT turn — the no-reseat per-turn semantics (§5).
    const effortGate = gateReasoningEffort(
      this.#reasoningEffort ?? this.#agent.reasoning_effort,
      this.#agent.model,
      this.#deps.resolveEffortTiers,
      this.#deps.withheldByCap !== undefined && this.#agent.max_tokens !== undefined
        ? { maxTokens: this.#agent.max_tokens, withheldByCap: this.#deps.withheldByCap }
        : undefined,
    );
    // Withholding is right; withholding silently is not. The host gets the verdict and says so — otherwise a tier
    // the user set is dropped, the turn runs at the provider's default, and nothing anywhere admits it. `capped`
    // (a budget model whose tier the request's cap withholds, review M6) is voiced through the same channel.
    if (
      effortGate.kind === 'rejected' ||
      effortGate.kind === 'uncontrollable' ||
      effortGate.kind === 'capped'
    ) {
      this.#deps.onEffortWithheld?.(effortGate, this.#agent.model);
    }
    const reasoningEffort = effortToSend(effortGate);
    return runAgentTurn({
      system: this.#systemPrompt(),
      messages: this.#turnMessages(),
      ...(llmTools.length > 0 ? { tools: llmTools } : {}),
      planEntries: plan.entries,
      chainCapabilities: this.#chainCapabilities(),
      ...(this.#agent.temperature === undefined ? {} : { temperature: this.#agent.temperature }),
      ...(this.#agent.max_tokens === undefined ? {} : { maxTokens: this.#agent.max_tokens }),
      ...(reasoningEffort === undefined ? {} : { reasoningEffort }),
      nodeId: this.#agentRef,
      emit: (event) => {
        this.#onTurnEmit(event);
      },
      // The session path's producer-await (`CR-30`) — this is the turn that streams a reply, so this is the
      // one that could grow a consumer's buffer without a bound.
      ...(this.#deps.whenReady === undefined ? {} : { whenReady: this.#deps.whenReady }),
      signal,
      registry: this.#deps.registry,
      dispatchContext,
      limits: this.#limits,
      ...(this.#deps.preEgress === undefined ? {} : { preEgress: this.#deps.preEgress }),
      ...(this.#deps.resolvePrice === undefined ? {} : { resolvePrice: this.#deps.resolvePrice }),
    });
  }

  /**
   * Forward an in-turn streaming body, stamping the session-wide running total onto `cost:updated`.
   * `cost:updated.costMicrocents` is the **per-attempt increment** the turn core emits (one event per
   * non-skipped attempt, agent-turn.ts), with a `0` cumulative placeholder; summing the increments is the
   * correct running total and mirrors how the `WorkflowEngine` owns it for a run (engine.ts `#nodeEmit`:
   * `#cumulativeCostMicrocents += event.costMicrocents`). It is robust to multiple cost events per turn
   * (e.g. a fallback or a tool round-trip), so it does not depend on exactly one event per turn.
   */
  #onTurnEmit(event: NodeStreamEvent): void {
    if (event.type === 'cost:updated') {
      this.#cumulativeCostMicrocents += event.costMicrocents;
      // Keep a host-wired budget governor's running total current so its pre-egress check sees the real
      // session spend (ADR-0028) — without this the governor would stay at 0 and a tool-looping chat would
      // not fail safe.
      this.#deps.updateCost?.(this.#cumulativeCostMicrocents);
      this.#deps.emit({ ...event, cumulativeCostMicrocents: this.#cumulativeCostMicrocents });
      return;
    }
    this.#deps.emit(event);
  }

  #emitTurnCompleted(
    stopReason: SessionStopReason,
    tokensUsed: { input: number; output: number; model?: string },
    error?: { code: ErrorCode; message: string; retryable: boolean },
  ): void {
    this.#deps.emit({
      type: 'session:turn_completed',
      stopReason,
      tokensUsed,
      ...(error === undefined ? {} : { error }),
    });
  }

  /**
   * Build the ordered fallback plan once: primary (maxAttempts 1, ADR-0040) + each authored fallback.
   * Memoized — including a FAILED resolution. A failure here means a provider the agent names was never
   * wired by the host (a construction-time wiring gap, fixed configuration for the session's lifetime), so
   * retrying per turn cannot change the outcome; caching it makes every `sendMessage` fail fast and
   * identically rather than re-walking the chain each turn.
   */
  #resolvePlan(): PlanResult {
    if (this.#plan !== undefined) return this.#plan;
    const agent = this.#agent;
    const primary = this.#deps.resolveProvider(agent.provider);
    if (primary === undefined) {
      this.#plan = { ok: false, message: `no provider wired for '${agent.provider}'` };
      return this.#plan;
    }
    // ADR-0040 makes node retry the engine's ABOVE-chain budget, and the primary entry does not consume it.
    // But a SESSION has no such loop (this comment used to end there, with `maxAttempts: 1`), so on the chat
    // and one-shot `agent run` surfaces the chain was the ONLY place a retry could happen — and with a budget
    // of 1 the guard `attempt < budget` is false, so `#backoff` is unreachable and nothing retried at all.
    // That was masked until #276: the vendor SDK's own retry was silently absorbing transient 429/5xx here.
    // With the SDK's retry correctly off, a bare 429 would fail the turn outright with no wait, so the primary
    // carries a minimal budget of 2 on this path. The WORKFLOW path deliberately stays at 1 (see
    // `agent-runner.ts`) because the engine retries above it there — raising both would multiply the authored
    // budget. Recorded as a dated amendment on ADR-0040.
    const entries: FallbackPlanEntry[] = [
      { provider: primary, model: agent.model, maxAttempts: SESSION_PRIMARY_MAX_ATTEMPTS },
    ];
    for (const entry of agent.fallback_chain ?? []) {
      const provider = this.#deps.resolveProvider(entry.provider);
      if (provider === undefined) {
        this.#plan = { ok: false, message: `no provider wired for fallback '${entry.provider}'` };
        return this.#plan;
      }
      entries.push({ provider, model: entry.model, maxAttempts: entry.max_attempts });
    }
    this.#plan = { ok: true, entries };
    return this.#plan;
  }

  /** Forward only the platform-level chain capabilities the host supplies (mirrors the 1.O runner). */
  #chainCapabilities(): ChainCapabilities {
    const deps = this.#deps;
    return {
      keyFor: deps.keyFor,
      sleep: deps.sleep,
      ...(deps.now === undefined ? {} : { now: deps.now }),
      ...(deps.onAuthError === undefined ? {} : { onAuthError: deps.onAuthError }),
      // The deadline is armed only when the host supplied a TIMER — the controller is always present (it
      // serves the per-turn cancel too), so `setTimer` is what expresses "both or neither" here.
      ...(deps.setTimer === undefined
        ? {}
        : { newAbortController: deps.newAbortController, setTimer: deps.setTimer }),
      ...(deps.attemptTimeoutMs === undefined ? {} : { attemptTimeoutMs: deps.attemptTimeoutMs }),
    };
  }
}

/**
 * Split the working transcript (ADR-0062) into the earlier part to FOLD into the summary and the last COMPLETE
 * `user`+`assistant` exchange to KEEP verbatim. The kept slice starts at the last `user` that is FOLLOWED by an
 * `assistant` reply — so a trailing dangling `user` (a completed-but-empty-text turn leaves one; `sendMessage`
 * only appends the assistant when `result.text` is non-empty) is never kept as a protocol-breaking LONE user;
 * it rides along at the tail of a complete exchange. `undefined` when there is no earlier turn to fold before
 * the last complete exchange (≤1 exchange — the `nothing_to_compact` / thrash-guard case).
 */
function splitFoldable(
  messages: readonly LlmMessage[],
): { readonly foldable: LlmMessage[]; readonly kept: LlmMessage[] } | undefined {
  // O(N): the kept exchange starts at the last `user` that PRECEDES the last `assistant` (any such user has an
  // assistant reply after it); a trailing dangling `user` rides along in the kept slice, never as a lone user.
  let lastAssistant = -1;
  for (let i = messages.length - 1; i >= 0; i -= 1) {
    if (messages[i]?.role === 'assistant') {
      lastAssistant = i;
      break;
    }
  }
  let keptStart = -1;
  for (let i = lastAssistant - 1; i >= 0; i -= 1) {
    if (messages[i]?.role === 'user') {
      keptStart = i;
      break;
    }
  }
  if (keptStart <= 0) return undefined; // no earlier turn precedes the last complete exchange
  return { foldable: messages.slice(0, keptStart), kept: messages.slice(keptStart) };
}

/** The concatenated text of a cross-turn message (the transcript is text-only; a non-text part is skipped). */
function messageText(message: LlmMessage): string {
  return message.content.map((part) => (part.type === 'text' ? part.text : '')).join('');
}

/**
 * Render the earlier conversation (an optional prior summary preamble + the foldable turns) as ONE `user`
 * message for the summariser (ADR-0062). Untrusted conversation data rides the USER role — never the authored
 * system prompt (the seam's system-is-authored rule). Including the prior preamble is what makes re-compaction
 * fold summary-of-summary (the disclosed, accepted degradation).
 */
function renderConversationToSummarise(
  priorSummary: Untrusted<string> | undefined,
  foldable: readonly LlmMessage[],
): LlmMessage {
  const parts: string[] = [];
  if (priorSummary !== undefined) {
    // Unwrapped into a USER message — the summariser reads the prior summary as data, exactly as the live
    // turn does. This is the second and last unwrap point, and it is a data position too.
    parts.push(
      `Summary of the conversation so far:\n${unwrapUntrusted(priorSummary)}`,
      'The conversation then continued:',
    );
  }
  for (const message of foldable) {
    const text = messageText(message);
    if (text.length === 0) continue;
    parts.push(`${message.role === 'user' ? 'User' : 'Assistant'}: ${text}`);
  }
  return { role: 'user', content: [{ type: 'text', text: parts.join('\n\n') }] };
}

/**
 * The last `maxKeep` messages, snapped to start on a `user` message so the trimmed transcript stays
 * protocol-valid (an orphan leading `assistant` — from slicing mid-exchange — is dropped; ADR-0062). It never
 * returns an EMPTY slice when there was history to keep: `maxKeep = 1` on a transcript ending in `assistant`
 * would forward-snap to empty (WIPING the whole transcript) — instead it floors at the last complete exchange
 * (the last `user` onward), so `/trim` keeps at least that exchange rather than silently erasing everything.
 */
function tailFromUserBoundary(messages: readonly LlmMessage[], maxKeep: number): LlmMessage[] {
  if (maxKeep <= 0 || messages.length === 0) return [];
  const windowStart = Math.max(0, messages.length - maxKeep);
  // Forward-snap: the first `user` at/after the window start (drops an orphan leading `assistant`). O(N).
  for (let i = windowStart; i < messages.length; i += 1) {
    if (messages[i]?.role === 'user') return messages.slice(i);
  }
  // The window held no `user` (all trailing assistants) — floor at the LAST `user` so a `/trim` never wipes the
  // transcript (the maxKeep=1-on-a-trailing-assistant case); an empty return only when there is no user at all.
  for (let i = messages.length - 1; i >= 0; i -= 1) {
    if (messages[i]?.role === 'user') return messages.slice(i);
  }
  return [];
}

/**
 * The agent's granted tools as LLM-visible defs, validated through the seam schema (no unsafe cast).
 * `advertise` is the optional mode advertise-filter (ADR-0057): a granted tool it rejects is **not** offered
 * to the model this turn (the `confirm` floor stays authoritative if the model names it anyway). Absent ⇒
 * every granted tool is advertised.
 */
function buildLlmTools(
  defs: readonly ToolDef[],
  granted: ReadonlySet<string>,
  delegates: ToolDelegates,
  advertise?: (toolId: string) => boolean,
): LlmToolDef[] {
  const out: LlmToolDef[] = [];
  for (const def of defs) {
    if (!granted.has(def.id)) continue;
    // A tool whose dispatch DELEGATE is absent cannot succeed, so it is never offered (`CR-73`). Before the
    // mode filter: this one is not best-effort and not mode-dependent — the delegate is either there or the
    // call is guaranteed to answer `tool_unavailable`.
    if (!delegateAvailable(def, delegates)) continue;
    if (advertise !== undefined && !advertise(def.id)) continue; // mode advertise-filter (ADR-0057)
    // The model-visible description carries a provenance line for a server-supplied tool (ADR-0088 §7.2).
    const description = modelVisibleDescription(def);
    const parsed = ToolDefSchema.safeParse({
      name: def.id,
      ...(description.length > 0 ? { description } : {}),
      parameters: def.llmVisibleParams,
    });
    if (!parsed.success) {
      // A registered tool carries an invalid LLM-visible schema — a host-wiring bug, not a model failure.
      // Classify it (rather than let a raw ZodError escape the turn) so it surfaces as a session error turn.
      throw new AgentTurnError(
        'internal',
        `granted tool '${def.id}' has an invalid LLM schema`,
        false,
      );
    }
    out.push(parsed.data);
  }
  return out;
}
