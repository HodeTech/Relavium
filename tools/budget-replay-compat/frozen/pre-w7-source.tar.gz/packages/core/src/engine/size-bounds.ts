/**
 * Size bounds at the durable boundary (`CR-32`,
 * [ADR-0087](../../../../docs/decisions/0087-consumed-streams-size-bounds-and-run-retention.md) §2).
 *
 * **The ADR is 0087, not 0086.** This file was written before its decision was recorded and pointed at the
 * ceilings ADR it merged beside; ADR-0086 governs ADMISSION ceilings on authored values and says nothing
 * about these three runtime bounds. Corrected 2026-09-04, when ADR-0087 was accepted.
 *
 * Three quantities were unbounded, and each fails differently when it grows: a single node's output (held in
 * memory for the whole run and re-serialised into every downstream template), the SUM of every node's output
 * (the workflow state a long graph accumulates), and one durable event (what the store is asked to write and
 * every consumer to receive).
 *
 * **This bounds by REJECTION, not truncation, and the distinction is the item's own wording.** The tool-result
 * bound in `tools/bounding.ts` truncates and spills, because a model-facing preview of a big file is still
 * useful. A workflow output is not a preview of anything: half a node's result silently flowing into the next
 * node's template is a wrong answer that looks like a right one. So an over-size output fails its node, with
 * the field, the size and the limit named.
 *
 * **The one thing a size bound may never do is stop a run from ending.** Exactly-one-terminal outranks every
 * ceiling here ([ADR-0036](../../../../docs/decisions/0036-run-loop-substrate-event-bus-and-execution-host.md)),
 * and [ADR-0078](../../../../docs/decisions/0078-ordered-durable-append-and-the-terminal-outbox.md) §6 already
 * narrows `#emitDurable`'s totality to the terminal arm for the same reason. A terminal event is therefore
 * **exempt** — see {@link measureDraft}.
 */

import { utf8ByteLength } from '../tools/bounding.js';

/**
 * The three bounds, in one object for the same reason `ADMISSION_CEILINGS` is: a caller that wants to show
 * them should not have to know three identifier names.
 */
export const SIZE_BOUNDS = {
  /** One node's output, serialised. Held for the run and re-read by every downstream template. */
  nodeOutputBytes: 256 * 1024,
  /** Every node output in the run, summed — the workflow state a long graph accumulates. */
  workflowStateBytes: 4 * 1024 * 1024,
  /** One durable event, serialised. What the store writes and every consumer receives. */
  durableEventBytes: 1024 * 1024,
} as const;

/**
 * The serialised size of a value in UTF-8 bytes, or `undefined` when it cannot be serialised at all.
 *
 * `undefined` is not "zero" and callers must not treat it as such: it means the value could not be measured
 * at all — a cycle, a `BigInt`, a function.
 *
 * **An earlier version of this comment justified letting such a value through by saying the emit boundary
 * rejects it. It does not, and that was measured**: a node returning a cyclic object completed its run and
 * the run finished `run:completed`, with the value retained in `#states` and no bound and no error anywhere.
 * So {@link measureNodeOutput} now treats unmeasurable as its own breach, with a message about the actual
 * problem rather than about a size — which is what a caller can act on.
 *
 * `undefined` as the VALUE itself serialises to nothing and is genuinely zero bytes — the common case for a
 * node that produces no output — so that is distinguished here rather than folded in with the failures.
 */
export function serialisedByteLength(value: unknown): number | undefined {
  if (value === undefined) {
    return 0;
  }
  try {
    const json = JSON.stringify(value, inlineMediaReplacer);
    // `JSON.stringify` returns `undefined` (not a throw) for a function or a bare symbol.
    return json === undefined ? undefined : utf8ByteLength(json);
  } catch {
    return undefined;
  }
}

/**
 * A `JSON.stringify` replacer that measures an inline media part as the HANDLE it becomes, not as the base64
 * it currently is.
 *
 * **This is the difference between bounding the durable boundary and bounding something that never reaches
 * it**, and getting it wrong broke every media-producing node. A node that generates an image returns
 * `{ kind: 'base64', data }` in flight; `deInlineMedia` replaces that with a `media://sha256-…` handle of
 * about a hundred bytes before anything is persisted or delivered. Measuring the raw form therefore failed a 200 KiB image against a
 * 256 KiB "durable event" bound whose real payload was ~100 bytes — with a `validation` error the author
 * could not act on, because they cannot make a model return fewer bytes.
 *
 * **`state.output` no longer keeps the raw form**, and this comment said it did for two waves. Since `W5`'s
 * `CR-54` the pin runs at the dispatch boundary and `#settleCompleted` writes the PINNED value into `#states`,
 * so state, downstream templates and the durable event all hold the handle (ADR-0087 §3, Correction 7). The
 * replacer still earns its place: it measures a value that has not been through the pin — a run with no
 * `MediaStore`, where the emit choke point makes the refusal one step later.
 *
 * The substitute is a fixed-length stand-in rather than the real digest: the handle's length is constant
 * (`media://` + a hex sha256), the value is not known until the store writes it, and a size estimate does not
 * need it. Inline bytes are bounded elsewhere and deliberately — `INLINE_MEDIA_CEILING` governs what may be
 * ingested, and generated media is exempt there precisely because the engine de-inlines it.
 */
const HANDLE_STAND_IN = `media://sha256-${'0'.repeat(64)}`;

/**
 * Whether a value is the media part `deInlineMedia` rewrites — `{ type: 'media', source: { kind: 'base64' } }`.
 *
 * **Narrow on the whole shape, not on `kind === 'base64'` alone.** A first version matched any object with a
 * `kind: 'base64'` and a `data` key, which is a plausible shape for an ordinary node output — a tool that
 * returns an encoded blob, say — and nothing de-inlines those. They would have been measured as a hundred-byte
 * handle and escaped the bound entirely, which is a hole in the bound rather than an inaccuracy in it.
 *
 * A type predicate rather than a cast: the project forbids an unsafe `as`, and the first version used one.
 */
function isInlineMediaPart(value: unknown): value is { source: { kind: 'base64' } } {
  if (typeof value !== 'object' || value === null) return false;
  const part: Record<string, unknown> = { ...value };
  if (part['type'] !== 'media') return false;
  const source = part['source'];
  if (typeof source !== 'object' || source === null) return false;
  const src: Record<string, unknown> = { ...source };
  return src['kind'] === 'base64' && typeof src['data'] === 'string';
}

function inlineMediaReplacer(_key: string, value: unknown): unknown {
  if (isInlineMediaPart(value)) {
    // Only the SOURCE is replaced; the part's other fields (`mimeType`, any metadata) survive to the durable
    // form and must keep counting, because they do reach the store.
    return { ...value, source: { kind: 'base64', data: HANDLE_STAND_IN } };
  }
  return value;
}

/** A size breach, shaped so a caller can build its own typed error without re-deriving the numbers. */
export interface SizeBreach {
  /** What was measured — `` node `x` output ``, `workflow state`, `` event `node:completed` ``. */
  readonly what: string;
  readonly bytes: number;
  readonly limit: number;
}

/**
 * Render a breach as a user-facing, secret-free message: the subject, the size, the limit, in that order.
 *
 * A `bytes` of 0 means the value could not be measured at all, and the size clause is dropped — "is 0 bytes,
 * above the limit of 262144" would be a nonsense sentence pointing an author at the wrong problem.
 */
export function describeBreach(breach: SizeBreach): string {
  return breach.bytes === 0
    ? breach.what
    : `${breach.what} is ${breach.bytes} bytes, above the limit of ${breach.limit}`;
}

/**
 * Measure one node's output against {@link SIZE_BOUNDS.nodeOutputBytes}.
 *
 * Returns the measured size alongside any breach, because the caller needs the number twice: once to refuse
 * this node, and once to add to the running workflow-state total when it does not.
 */
export function measureNodeOutput(
  nodeId: string,
  output: unknown,
): { readonly bytes: number; readonly breach?: SizeBreach } {
  const bytes = serialisedByteLength(output);
  if (bytes === undefined) {
    // Unmeasurable is its own failure, not a free pass. The message names the real problem — a size figure
    // would be a fabrication, and there is none to report.
    return {
      bytes: 0,
      breach: {
        what: `node \`${nodeId}\` output is not serialisable (a cycle, a BigInt or a function)`,
        bytes: 0,
        limit: SIZE_BOUNDS.nodeOutputBytes,
      },
    };
  }
  return bytes > SIZE_BOUNDS.nodeOutputBytes
    ? {
        bytes,
        breach: { what: `node \`${nodeId}\` output`, bytes, limit: SIZE_BOUNDS.nodeOutputBytes },
      }
    : { bytes };
}

/** Measure the accumulated workflow state against {@link SIZE_BOUNDS.workflowStateBytes}. */
export function measureWorkflowState(totalBytes: number): SizeBreach | undefined {
  return totalBytes > SIZE_BOUNDS.workflowStateBytes
    ? { what: 'the workflow state', bytes: totalBytes, limit: SIZE_BOUNDS.workflowStateBytes }
    : undefined;
}

/**
 * Measure one durable event against {@link SIZE_BOUNDS.durableEventBytes}.
 *
 * **A terminal draft is EXEMPT: not measured, and never refused.** That is not a softening — it is the
 * invariant every other rule here defers to. (This doc and ADR-0087 §2 both said "measured and never refused"
 * until 2026-09-04. The function returns before it measures, so nothing was measured and nothing reported;
 * `exempt` is the word that matches the code. See ADR-0087's Correction 4.) A run that cannot publish its
 * terminal is worse in every way than one that wrote
 * an oversized final event: the stream never closes, the lease is never released, and no surface can tell
 * whether the run finished. ADR-0078 §6 draws the same line for a store fault, for the same reason.
 *
 * Non-terminal drafts are refused, which is safe precisely because refusing one is itself a node failure that
 * produces a terminal.
 */
export function measureDraft(
  type: string,
  draft: unknown,
  isTerminal: boolean,
): SizeBreach | undefined {
  if (isTerminal) {
    return undefined;
  }
  const bytes = serialisedByteLength(draft);
  if (bytes === undefined || bytes <= SIZE_BOUNDS.durableEventBytes) {
    return undefined;
  }
  return { what: `event \`${type}\``, bytes, limit: SIZE_BOUNDS.durableEventBytes };
}
