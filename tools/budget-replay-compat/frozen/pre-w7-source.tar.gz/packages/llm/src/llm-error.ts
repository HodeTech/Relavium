import type { LlmError, LlmErrorKind, ProviderId } from './types.js';

/**
 * `LlmError` classification — the contract the `FallbackChain` (1.K) narrows on (1.I). Every adapter
 * normalizes its SDK's failures into this one shape *before* crossing the seam, so the engine never
 * sees a vendor error. The classification (retryable vs fatal) is a pure function of `kind`, so the
 * two fields can never disagree. See [error-handling.md](../../../docs/standards/error-handling.md).
 */

/**
 * The four retryable kinds — the fallback chain advances to the next provider on these (with
 * backoff) and records the failed attempt's usage so cost stays accurate. Every other kind is fatal:
 * it stops the chain rather than silently masking a real problem.
 */
export const RETRYABLE_KINDS: ReadonlySet<LlmErrorKind> = new Set<LlmErrorKind>([
  'rate_limit',
  'overloaded',
  'timeout',
  'transport',
]);

/** Whether a kind is retryable. The single source of truth for `LlmError.retryable`. */
export const isRetryable = (kind: LlmErrorKind): boolean => RETRYABLE_KINDS.has(kind);

/**
 * Map an upstream HTTP status to a kind — the shared baseline every adapter reuses. An adapter
 * refines it with provider-specific nuance (a typed SDK error class, a body error code) before
 * falling back to this.
 */
export function kindFromHttpStatus(status: number): LlmErrorKind {
  if (status === 429) return 'rate_limit';
  if (status === 529) return 'overloaded';
  if (status === 408) return 'timeout';
  if (status >= 500) return 'overloaded'; // 5xx — a transient server/overload condition
  if (status === 401 || status === 403) return 'auth';
  // 402 Payment Required — a provider account/billing problem (e.g. DeepSeek's "Insufficient Balance", an
  // exhausted prepaid quota), NOT an engine fault. Rides the fatal `auth` bucket → `provider_auth`, so the
  // surfaced code names an account problem instead of `unknown` → `internal`. Fatal (non-retryable): retrying
  // the same provider cannot restore balance. Grouped with 401/403 in error-handling.md.
  if (status === 402) return 'auth';
  // 400 bad request · 404 not found · 409 conflict · 413 too large · 422 unprocessable — all fatal.
  if (status === 400 || status === 404 || status === 409 || status === 413 || status === 422) {
    return 'bad_request';
  }
  return 'unknown';
}

/**
 * The `Error` a provider's `generate` rejects with, carrying the normalized `LlmError`. The
 * `FallbackChain` (1.K) catches this and narrows on `.llmError` for its retry/fatal decision. A
 * `stream` surfaces the same `LlmError` in an `error` `StreamChunk` instead of throwing.
 */
export class LlmProviderError extends Error {
  readonly llmError: LlmError;

  constructor(llmError: LlmError) {
    super(llmError.message);
    this.name = 'LlmProviderError';
    this.llmError = llmError;
  }
}

interface MakeLlmErrorArgs {
  readonly provider: ProviderId;
  readonly kind: LlmErrorKind;
  /** Human-readable, **redacted of secret material by the caller** (a key, a full prompt). `makeLlmError`
   *  additionally scrubs common secret shapes as a backstop at this one choke point (see `scrubSecrets`). */
  readonly message: string;
  /** Normalized provider/transport code, e.g. 'rate_limit'. */
  readonly code?: string;
  /** Upstream HTTP status, when there was one. */
  readonly status?: number;
  /** Original error, for debugging only — never re-thrown across the seam. */
  readonly cause?: unknown;
  /** The provider's own requested wait, normalized to ms (#279). Set only when a header supplied it. */
  readonly retryAfterMs?: number;
}

/**
 * Defense-in-depth secret scrub applied at the one `makeLlmError` choke point. The CALLER (adapter) is
 * still responsible for passing an already-redacted message; this is the **structural backstop** — like
 * the engine's `deInlineMedia` pass, leak-freedom here is an active transform at one boundary, not
 * per-adapter discipline — so a forgotten adapter redaction cannot leak a key / token / credentialed URL
 * across the seam, into a run event, or into a log. It masks the common secret **shapes** seen in
 * practice (a key in the message, a token in a URL query string, credentials in a URL userinfo, a Bearer
 * header); it never alters benign error text. Pure and total: regex replacement only, never throws (the
 * error path must not throw). Asserted by `llm-error.test.ts` (the backstop) and each adapter's
 * secret-safety test (a planted secret → a secret-free surfaced `LlmError`); see security-review.md.
 */
export function scrubSecrets(text: string): string {
  return text
    .replace(/(https?:\/\/)[^/\s:@]+(?::[^/\s@]+)?@/gi, '$1[REDACTED]@') // URL userinfo: user@ or user:pass@
    .replace(
      /([?&](?:(?:x[-_])?api[-_]?key|key|token|access[-_]?token|auth|password|secret)=)[^&\s#]+/gi,
      '$1[REDACTED]',
    ) // secret in a URL query string (incl. `x-api-key` — an opaque value has no prefix to catch below)
    .replace(/\bBearer\s+\S+/gi, 'Bearer [REDACTED]') // Authorization: Bearer <token> — any token shape up to whitespace
    .replace(/\bBasic\s+\S+/gi, 'Basic [REDACTED]') // Authorization: Basic <base64 user:pass>
    .replace(/\bsk-(?:ant-)?[A-Za-z0-9\-_]{16,}/g, '[REDACTED]') // OpenAI sk-/sk-proj-/sk-svcacct- + Anthropic sk-ant- key prefixes
    .replace(/\bAIza[0-9A-Za-z\-_]{20,}/g, '[REDACTED]'); // Google API key prefix
}

/**
 * Build a normalized `LlmError`, deriving `retryable` from `kind` so a miswired adapter can't
 * produce an inconsistent pair. Constructs directly (no Zod parse) so it never throws on the error
 * path — the TS types already pin the shape. `message`/`code` pass through `scrubSecrets` (the backstop).
 */
export function makeLlmError(args: MakeLlmErrorArgs): LlmError {
  const error: LlmError = {
    kind: args.kind,
    retryable: isRetryable(args.kind),
    provider: args.provider,
    message: scrubSecrets(args.message),
  };
  if (args.code !== undefined) {
    error.code = scrubSecrets(args.code);
  }
  if (args.status !== undefined) {
    error.status = args.status;
  }
  if (args.retryAfterMs !== undefined) {
    error.retryAfterMs = args.retryAfterMs;
  }
  // `cause` is an INTERNAL diagnostic only (error-handling.md): it is NOT scrubbed and may hold a raw
  // vendor object, so it must never be logged/serialized raw. The run-event boundary already carries
  // only { code, message, retryable } (run-event.ts), never `cause`; a future adapter that sets `cause`
  // keeps it off any log/event sink (or scrubs at that boundary).
  if (args.cause !== undefined) {
    error.cause = args.cause;
  }
  return error;
}

/**
 * Normalize a provider's requested wait to milliseconds, from either header shape (#279).
 *
 * Both Anthropic and OpenAI send `retry-after` (RFC 7231: delta-seconds OR an HTTP-date) and the Stainless
 * SDKs additionally send `retry-after-ms`. Only a value the provider actually supplied is returned —
 * `undefined` means "no instruction", never "wait zero", so the caller keeps its own backoff.
 *
 * Defensive by design: a header is untrusted input. A non-numeric, negative, or absurd value is dropped
 * rather than honoured, because a hostile or broken `retry-after: 999999999` would otherwise park a turn
 * indefinitely. The ceiling is the caller's problem too, but rejecting nonsense here keeps one rule in one place.
 */
export function retryAfterMsFromHeaders(headers: {
  readonly get: (name: string) => string | null | undefined;
}): number | undefined {
  const ms = headers.get('retry-after-ms');
  if (ms !== null && ms !== undefined && ms.trim() !== '') {
    const parsed = Number(ms);
    if (Number.isFinite(parsed) && parsed >= 0) return clampRetryAfter(parsed);
  }
  const after = headers.get('retry-after');
  if (after === null || after === undefined || after.trim() === '') return undefined;
  const seconds = Number(after);
  if (Number.isFinite(seconds) && seconds >= 0) return clampRetryAfter(seconds * 1000);
  // An HTTP-date form: honour it only if it is in the future by a sane margin.
  const at = Date.parse(after);
  if (Number.isNaN(at)) return undefined;
  return clampRetryAfter(at - Date.now());
}

/** The hard ceiling on a provider-requested wait. Beyond it we wait the ceiling — we do not ignore the ask. */
const RETRY_AFTER_CEILING_MS = 60_000;

/**
 * CLAMP, never drop. Dropping an over-ceiling value looked safer but is strictly worse: a provider legitimately
 * asking for 120 s fell back to our own curve and retried after ~250 ms — hammering the exact endpoint that
 * just told us to back off, and far more aggressively than honouring a capped 60 s would. The ceiling exists to
 * stop a hostile/broken `retry-after: 999999999` parking a turn, and clamping does that just as well while
 * still respecting a real instruction.
 *
 * Only genuinely uninterpretable values (non-finite, negative — i.e. "this is not a wait") yield `undefined`,
 * which means "no instruction" and lets the caller keep its own backoff.
 */
function clampRetryAfter(ms: number): number | undefined {
  if (!Number.isFinite(ms) || ms < 0) return undefined;
  return Math.round(Math.min(ms, RETRY_AFTER_CEILING_MS));
}
