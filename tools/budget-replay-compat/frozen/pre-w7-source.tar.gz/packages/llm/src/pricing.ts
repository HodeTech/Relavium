import type { MediaBilledModality } from '@relavium/shared';

import type { CatalogPriceTier } from './catalog/catalog-model.js';
import { catalogModel } from './catalog/lookup.js';
import type { ProviderId } from './types.js';

/**
 * The **pricing contract** — what a price IS, not what any model costs
 * ([ADR-0071](../../../docs/decisions/0071-models-dev-as-the-model-metadata-source.md) §1).
 *
 * The twelve-row hand-typed `MODEL_PRICING` table that used to live here is GONE. It was our own verified data
 * once; by the time it was retired it had drifted from reality on two numbers (`claude-sonnet-4-6`'s output
 * ceiling, `gpt-5.5`'s context window) and nobody had noticed, because nothing compared it to anything. That is
 * not a maintenance failure — it is what a hand-typed table of someone else's prices always becomes.
 *
 * The numbers now come from the generated catalog (`catalog/snapshot.ts`, synced from models.dev) via
 * {@link catalogPricing}, and from the USER, who outranks it: they hold the invoice, we hold a snapshot of a
 * third-party aggregator. `priceModel` resolves **user → catalog → throw**.
 *
 * The shape survives because it is a contract: the `CostTracker` bills against it, the pre-egress governor
 * estimates against it, and a `models pricing` row IS one. Prices are **integer micro-cents per million tokens**
 * (1 micro-cent = 1e-8 USD) — no float, ever. USD/MTok → micro-cents/MTok is `usd × 1e8`.
 */

export interface ModelPricing {
  /** The seam provider this model belongs to. */
  readonly provider: ProviderId;
  /** The provider-native model id the adapter sends (often equal to the canonical key). */
  readonly nativeId: string;
  readonly displayName: string;
  readonly contextWindowTokens: number;
  readonly maxOutputTokens: number;
  readonly inputPerMtokMicrocents: number;
  readonly outputPerMtokMicrocents: number;
  /**
   * Cache-read (cached-input) price — **never 0 for "no discount"** (ADR-0071 §10).
   *
   * `cost()` bills `cacheReadTokens × this / 1e6`, so 0 does not mean "charge the normal rate", it means **charge
   * nothing**. A provider that publishes no cache-read rate does not discount cache reads; it does not hand them
   * out free. The projection from the catalog therefore falls back to {@link ModelPricing.inputPerMtokMicrocents},
   * and a user row that omits the dimension inherits the catalog's rather than zeroing it.
   */
  readonly cachedInputPerMtokMicrocents: number;
  /** Cache-write price, where the provider charges one (Anthropic does); undefined otherwise. */
  readonly cacheWritePerMtokMicrocents?: number;
  /**
   * Context-size pricing tiers — "above N context tokens, the rate changes" (ADR-0071 §11).
   *
   * `gemini-2.5-pro` is $1.25/$10 below 200k and **$2.50/$15 above**; `gpt-5.5` and eleven other models the catalog
   * newly prices are tiered at 272k. A flat rate understates long-context spend by up to 2×, and the cost cap is a
   * SAFETY control, not an estimate. The realized fold prices the tier the prompt actually landed in; the
   * pre-egress estimate takes the HIGHEST applicable one, because a cap that over-estimates refuses a turn the user
   * could have afforded while one that under-estimates lets real money escape. Only one of those is recoverable.
   *
   * A USER row carries none: their stated price is a flat price, which is what they told us.
   */
  readonly contextTiers?: readonly CatalogPriceTier[];
  /**
   * ISO-8601 date this model is scheduled to retire, if any (ADR-0064 §7). The pure {@link mergeModelCatalog}
   * flags an entry `deprecated` once `now >= deprecatedAt` (unioned with a live-list deprecation date, taking
   * the earlier). The picker flags a deprecated model but never forbids it — a legacy alias still costs
   * correctly until its date. Absent ⇒ not deprecated.
   */
  readonly deprecatedAt?: string;
  /**
   * Per-modality media **output** rates (1.AF/D17,
   * [ADR-0044](../../../docs/decisions/0044-media-access-governance-read-media-save-to-cost.md) §3) — integer
   * micro-cents per billed unit: `image` per image (the unit is a count), `audio`/`video` per second. The
   * keys are exactly the `MEDIA_BILLED_MODALITIES` (`document`/PDF bills as tokens, so it is excluded). A
   * **missing** modality rate (or an absent `mediaOutputRates`) means the model has no metered media rate —
   * the realized fold and the pre-egress estimate **degrade to 0** for it (H4: never hard-fail a valid run on
   * a missing rate), and a token-count audio unit from a token-based provider stays observability-only until a
   * per-count rate exists. No 1.AF model emits billed media output, so every row leaves this undefined; the
   * shape is the seam for the model catalog's media rates.
   */
  // Keyed by the canonical `MediaBilledModality` set (image/audio/video) via a mapped type, so the keys
  // stay in sync with `MEDIA_BILLED_MODALITIES` at compile time — never a hand-maintained literal.
  readonly mediaOutputRates?: { readonly [K in MediaBilledModality]?: number };
  // `reasoning?: boolean` lived here, and is GONE (ADR-0071 §6). "Does this model reason" is not the question the
  // wire asks — `gpt-5.4-pro` reasons AND rejects `low`, `claude-haiku-4-5` reasons with no effort ladder at all,
  // `gemini-2.5-pro` reasons and cannot be turned off. The catalog carries the CONTROL, and `effortTiersFor` reads
  // it. A price is a price; it was never the right place to answer a capability question.
}

// `MODEL_PRICING`, `CanonicalModelId`, `isCanonicalModelId`, `KNOWN_MODEL_IDS` lived here — all GONE (ADR-0071 §1).
//
// Twelve models, hand-typed from four pricing pages, re-verified by hand whenever someone remembered. The catalog
// carries eighty, generated, with an output ceiling and a per-model reasoning control the table never had — and it
// is regenerated by `pnpm sync:models` with money-guards that refuse a silent price change.
//
// `isCanonicalModelId` is not replaced by an equivalent. It asked "is this one of OUR models", and the honest
// question is "can we price this one" — `catalogPricing(id) !== undefined`, or `priceModel`'s own throw. The
// difference matters: a user-priced model is perfectly billable and was never "canonical".

// `reasoningModelIdHeuristic` / `modelSupportsReasoning` lived here too, and are GONE (ADR-0071 §6).
//
// They answered "does this model reason" by pattern-matching its id — `/^o\d/`, `startsWith('gpt-5')`, and so on —
// and that is not the question the wire asks. `gpt-5.4-pro` reasons AND rejects `low`; `claude-haiku-4-5` reasons
// and has no effort ladder at all; `gemini-2.5-pro` reasons and cannot be turned off. A boolean answers `true` to
// every one of them, and the tier the user picked went straight to the provider. `effortTiersFor(id)` is the one
// predicate every surface asks now.

/**
 * The context window for a model id, or `undefined` for one the catalog does not carry (a custom base-URL model).
 * A light, pure host-side helper — the SAME value the adapters' `LlmProvider.contextLimit` returns — for UI that
 * needs the window WITHOUT going through the provider seam: the ADR-0062 §7 footer context-fullness indicator
 * (last input tokens ÷ window). A custom-model `undefined` degrades the indicator to "not shown", exactly as it
 * degrades auto-compaction (ADR-0062 §5).
 *
 * It read the hand-typed table until 2026-07-13, and the table said `gpt-5.5`'s window was 1 000 000 while the
 * generated catalog said 1 050 000 — so the fullness percentage every user saw was computed against a window the
 * model does not have.
 */
export function contextWindowForModel(model: string): number | undefined {
  return catalogModel(model)?.contextWindowTokens;
}
