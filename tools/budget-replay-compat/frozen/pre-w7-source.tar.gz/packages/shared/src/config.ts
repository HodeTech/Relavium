import { z } from 'zod';

import { McpConnectTimeoutSchema } from './agent.js';
import { URL_HAS_CREDENTIALS, nonEmptyString, nonNegativeInt, positiveInt } from './common.js';
import { validateDeclaredEnv } from './declared-env.js';
import {
  FS_SCOPE_TIERS,
  LLM_PROVIDERS,
  ON_EXCEED_ACTIONS,
  REASONING_EFFORTS,
} from './constants.js';

/**
 * Configuration schemas (config-spec.md). Validation only — no file IO. The global
 * `config.toml` and the per-project `project.toml` / `workspace.toml` are stable,
 * versioned, committed formats; the per-project layer overrides the global one.
 */

export const UpdateChannelSchema = z.enum(['stable', 'beta']);

/** Filesystem permission tier (built-in-tools.md) — derived from the shared tier vocabulary. */
export const FsScopeSchema = z.enum(FS_SCOPE_TIERS);

/** A registered network MCP server must use http(s) (`http`) or ws(s) (`websocket`) — never file:/javascript:/etc. */
const SAFE_HTTP_URL = /^https?:\/\//i;
const SAFE_WS_URL = /^wss?:\/\//i;

/** The authored shape `McpServerRegistrationSchema.superRefine` validates (connection fields optional pre-refine). */
interface McpRegistrationDraft {
  name: string;
  transport: 'stdio' | 'http' | 'websocket' | 'sse';
  command?: string | undefined;
  args?: readonly string[] | undefined;
  autostart?: boolean | undefined;
  url?: string | undefined;
  env?: Record<string, string> | undefined;
  allow_local_endpoint?: boolean | undefined;
  connect_timeout_ms?: number | undefined;
}

/** `stdio` registration: needs a `command`; rejects the network-only `url` / `allow_local_endpoint` so a committed
 *  registration's contract matches the inline `McpServerRefSchema` (a dead flag would also skew `serverFingerprint`). */
function validateStdioRegistration(server: McpRegistrationDraft, ctx: z.RefinementCtx): void {
  // The same declared-environment rule the inline `mcp_servers` entry and `run_command` are held to
  // (ADR-0084 §4), reported the same echo-safe way: an env key's charset is unconstrained, and a `custom`
  // issue's message reaches a terminal on paths that do not sanitize.
  validateDeclaredEnv(server.env, ctx);
  if (!server.command) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: "command is required for the 'stdio' transport",
      path: ['command'],
    });
  }
  if (server.url !== undefined) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: "url is not used by the 'stdio' transport",
      path: ['url'],
    });
  }
  if (server.allow_local_endpoint !== undefined) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message:
        "allow_local_endpoint is not used by the 'stdio' transport (network transports only)",
      path: ['allow_local_endpoint'],
    });
  }
}

/** Network registration (`http`/`websocket`): needs a scheme-checked, credential-free `url`; rejects `env` (no child
 *  process to inject into — 2.R wires `env` ONLY into a stdio spawn; network header-auth is a tracked follow-up). */
function validateNetworkRegistration(server: McpRegistrationDraft, ctx: z.RefinementCtx): void {
  if (!server.url) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: `url is required for the '${server.transport}' transport`,
      path: ['url'],
    });
  }
  // Reject the stdio-only fields `command`/`args`/`env` on a network registration — symmetric with the inline
  // `McpServerRefSchema`; a network transport spawns no child, so they are inert (and would skew the fingerprint).
  for (const field of ['command', 'args', 'env'] as const) {
    if (server[field] !== undefined) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: `${field} is not used by a network transport — it applies only to a stdio server process${field === 'env' ? ' (network header-auth is a follow-up)' : ''}`,
        path: [field],
      });
    }
  }
  if (server.url !== undefined) {
    const schemeOk =
      server.transport === 'websocket'
        ? SAFE_WS_URL.test(server.url)
        : SAFE_HTTP_URL.test(server.url);
    if (!schemeOk) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: 'url scheme is invalid (http → http(s), websocket → ws(s))',
        path: ['url'],
      });
    }
    if (URL_HAS_CREDENTIALS.test(server.url)) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: 'url must not embed credentials (user:pass@…) — use env/keychain auth',
        path: ['url'],
      });
    }
  }
}

/**
 * An MCP server registration (`[[mcp_servers]]`). The transport dictates the required connection field:
 * `stdio` needs a `command`; `http` (Streamable HTTP) / `websocket` need a `url`; `sse` is the deprecated alias
 * of `http` (accepted for older servers, same `http(s)` url). Reconciled with the agent `McpServerRefSchema` to
 * one vocabulary — `stdio | http | websocket` (+ the `sse` alias)
 * ([ADR-0052](../decisions/0052-inbound-mcp-client-package-lifecycle-registration.md) §5).
 */
export const McpServerRegistrationSchema = z
  .object({
    name: nonEmptyString,
    transport: z.enum(['stdio', 'http', 'websocket', 'sse']),
    command: z.string().optional(),
    args: z.array(z.string()).optional(),
    autostart: z.boolean().optional(),
    url: z.string().url().optional(),
    env: z.record(z.string(), z.string()).optional(),
    // Opt into a private/loopback network endpoint (ADR-0053 §3) — see `McpServerRefSchema`. Network transports only.
    allow_local_endpoint: z.boolean().optional(),
    // Raise this server's connect deadline (ADR-0088 §1.4). The SAME schema the inline form uses, deliberately:
    // a registration that accepted a value the inline form refuses would make `ref` a way around the ceiling.
    connect_timeout_ms: McpConnectTimeoutSchema.optional(),
  })
  // .strict(): a typo in a committed MCP key (e.g. `autostrat`) fails loudly — strict config per ADR-0033 (which amends ADR-0023's config carve-out).
  .strict()
  .superRefine((server, ctx) => {
    if (server.transport === 'stdio') validateStdioRegistration(server, ctx);
    else validateNetworkRegistration(server, ctx);
  });
export type McpServerRegistration = z.infer<typeof McpServerRegistrationSchema>;

/** `~/.relavium/config.toml` — global preferences + MCP registrations.
 *  `.strict()`: a typo in a committed config key fails loudly rather than being silently dropped —
 *  config files are strict too per ADR-0033 (which amends ADR-0023's config carve-out). */
export const GlobalConfigSchema = z
  .object({
    update_channel: UpdateChannelSchema.optional(),
    /**
     * The model-metadata catalog ([ADR-0071](../../../docs/decisions/0071-models-dev-as-the-model-metadata-source.md) §4).
     *
     * Relavium ships a generated snapshot of models.dev — every price, ceiling and reasoning control, embedded in the
     * binary and answering **offline**. That is the whole design, and it is what makes the default here `false`.
     */
    catalog: z
      .object({
        /**
         * Refresh the catalog from models.dev automatically. **DEFAULT `false`, and deliberately.**
         *
         * A local-first tool that contacts a third party BY DEFAULT violates its own spirit even when the payload is
         * innocuous (CLAUDE.md rule 6) — so the standing background egress is opt-in, and the shipped snapshot is a
         * complete answer without it. [ADR-0068](../../../docs/decisions/0068-full-screen-tui-renderer-ink7-harness.md)
         * established the convention this follows: ship a new risk-bearing surface default-OFF, validate it, then
         * decide about flipping.
         *
         * `relavium models refresh` fetches regardless — an explicit command IS consent. That is what makes
         * default-OFF a livable default rather than a dead end: a user who wants current prices types one command.
         */
        auto_refresh: z.boolean().optional(),
      })
      .strict()
      .optional(),
    preferences: z
      .object({
        default_model: z.string().optional(),
        // The provider that serves `default_model`, PERSISTED at pick time (ADR-0059 — the provider is authoritative,
        // never re-inferred from the id). Written alongside `default_model` by the `/models` picker + the onboarding
        // wizard so a next-session chat over a live-discovered id whose spelling the prefix map cannot place (e.g.
        // `chatgpt-4o-latest`) still resolves its provider. Absent ⇒ fall back to prefix/catalog inference.
        default_provider: z.enum(LLM_PROVIDERS).optional(),
        theme: z.string().optional(),
        // The GLOBAL default reasoning-effort tier (ADR-0066 §6) — the effort counterpart of `default_model`, the
        // write target of the `/models` picker's effort sub-step. Resolved BELOW project/workspace
        // `[chat].reasoning_effort` (config-spec.md), so a project override still wins; absent ⇒ the provider default.
        reasoning_effort: z.enum(REASONING_EFFORTS).optional(),
        // Full-screen alt-screen renderer (2.6.F, ADR-0068 §e). The DEFAULT is ON for an interactive TTY, so this key
        // is the durable OPT-OUT: `false` (like the `--no-alt-screen` flag) keeps the byte-identical INLINE renderer
        // (native scrollback + the emulator's own a11y), the screen-reader fallback; `true` forces it on. The flag
        // overrides this key; a non-TTY / machine (`--json`/CI) path ignores both and always renders inline.
        alt_screen: z.boolean().optional(),
        // Terminal MOUSE reporting (DECSET 1002+1006) in the full-screen renderer (2.6.F, ADR-0068 §e). It is what
        // makes the wheel scroll the transcript and what lets Relavium run its OWN click-drag selection, since the
        // emulator forwards clicks to us instead of selecting. DEFAULT ON. `false` (like `--no-mouse`) turns it off
        // durably: the wheel stops scrolling (PgUp/PgDn/Ctrl+Home/Ctrl+End still page), in-app selection goes with it,
        // and the emulator's native selection works again. The flag overrides this key.
        // Ignored outside the alt screen — the inline renderer NEVER enables mouse reporting.
        mouse: z.boolean().optional(),
        // COPY-ON-SELECT (2.6.F Step 6e, ADR-0068 §e amendment): releasing a drag writes the selection to the system
        // clipboard over OSC 52. DEFAULT ON, matching every competing agent CLI. `false` keeps the highlight (and the
        // wheel) but never touches the clipboard — for anyone who does not want a stray drag clobbering what they
        // copied elsewhere. `/copy` still copies the whole transcript on demand. Meaningless without `mouse`, and
        // ignored when it is off: there is no selection to copy.
        copy_on_select: z.boolean().optional(),
        // The branded Home BANNER (2.6.F Step 5g, ADR-0068). `true` ⇒ always shown, `false` ⇒ never.
        // ABSENT ⇒ shown only while the Home is EMPTY (no sessions/runs/agents to continue) — an empty Home is the
        // "first opens" signal the ADR wanted, without a durable counter. Cosmetic: it gates no feature.
        show_banner: z.boolean().optional(),
      })
      .strict()
      .optional(),
    mcp_servers: z.array(McpServerRegistrationSchema).optional(),
  })
  .strict();
export type GlobalConfig = z.infer<typeof GlobalConfigSchema>;

/**
 * Chat-mode (`[chat]`) defaults for the agent-first entry point (config-spec.md, ADR-0024).
 * Distinct from `[defaults]` (which governs workflow runs); a chat session may carry its own pre-egress cost cap
 * (`max_cost_microcents` + `on_exceed`) enforced by the same governor as a workflow budget (ADR-0028), and — since
 * 2.5.D ([ADR-0061](../../../docs/decisions/0061-cli-input-layer-file-injection-and-shell-escape.md)) — its own
 * `allowed_commands` / `allowed_command_globs` gating the `!`-shell escape (mapping to the engine's camelCase
 * `allowedCommands` / `allowedCommandGlobs`). **Empty/absent ⇒ `!`-shell is disabled** (the `empty ⇒ disabled`
 * symmetry security-review.md pins) — there is NO chat-specific relaxation of the command allowlist.
 */
export const ChatConfigSchema = z
  .object({
    default_model: z.string().optional(),
    // The provider serving `[chat].default_model`, persisted at pick time (ADR-0059). See the identical
    // `[preferences].default_provider` note above; the project layer overrides the global one, like `default_model`.
    default_provider: z.enum(LLM_PROVIDERS).optional(),
    fs_scope: FsScopeSchema.optional(),
    // `!`-shell allowlist (ADR-0061): exact full-command-string match (`allowed_commands`) + opt-in glob patterns
    // (`allowed_command_globs`, riskier). Both empty/absent ⇒ `!` denied (secure-by-default; the user opts in per
    // config-spec.md `[chat]`). Enforced by the SAME `enforcePolicy(allowedCommands)` the workflow run_command uses.
    allowed_commands: z.array(nonEmptyString).optional(),
    allowed_command_globs: z.array(nonEmptyString).optional(),
    // Hard session **turn cap** — the surface-mapped form of the engine knob `SessionDeps.maxTurns`
    // (a finite DoS fail-safe; engine default 50, absent ⇒ that default). This config field is a
    // `positiveInt`, so 0 is rejected at parse and never reaches the engine's own `<= 0 ⇒ default` arm.
    // A `sendMessage` past the cap ends loudly (`session:turn_completed` `turn_limit`, no egress).
    // DISTINCT from `max_messages` (a history-**trim** threshold that silently continues) and the
    // within-turn `maxToolTurns` guard.
    max_turns: positiveInt.optional(),
    max_messages: positiveInt.optional(), // history-trim threshold — consumed by `/trim` + auto-compaction (ADR-0062)
    // Automatic context compaction (ADR-0062). `auto_compact` gates the after-turn threshold check (absent ⇒
    // enabled — the read site applies `?? true`); `compact_threshold` is the fraction of the model's context
    // window that, once the last turn's real input tokens exceed it, triggers a compaction before the next
    // turn (absent ⇒ 0.8). A fraction in (0, 1].
    auto_compact: z.boolean().optional(),
    compact_threshold: z.number().gt(0).lte(1).optional(),
    max_cost_microcents: nonNegativeInt.optional(), // 0/absent = unbounded; >0 = per-session cap
    on_exceed: z.enum(ON_EXCEED_ACTIONS).optional(),
    // Refuse a turn on a model we cannot PRICE (ADR-0071 §K7). Default false. The chat counterpart of a workflow
    // `budget.strict_cost_cap`: an unpriced model is a hole in the cap, and a user who set `max_cost_microcents`
    // to bound an untrusted model may prefer "if you can't price it, don't run it" over the silent degrade.
    strict_cost_cap: z.boolean().optional(),
    // The default reasoning-effort tier for a chat whose bound agent authors none (ADR-0066) — off/low/medium/high/
    // max. Applied to the built-in default chat agent + surfaced as the picker's starting effort; only sent to a
    // reasoning-capable model. Absent ⇒ the provider default (no reasoning control sent).
    reasoning_effort: z.enum(REASONING_EFFORTS).optional(),
  })
  .strict() // fail loud on an unknown [chat] key (strict config — ADR-0033, amends ADR-0023)
  .optional();

/**
 * Per-modality media-output **unit-count** default for the pre-egress media cost estimate (1.AF/D17,
 * [ADR-0044](../../../docs/decisions/0044-media-access-governance-read-media-save-to-cost.md) §3) — the analogue of
 * `max_tokens_estimate`, but a **count** not a price: how many billed units (images, audio-seconds,
 * video-seconds) a media-output turn is assumed to produce when it does not declare its own volume. The
 * per-unit **price** lives in the model catalog (`ModelPricing.mediaOutputRates`), never here. `document`
 * is absent (PDF bills as tokens, never a chat-turn output — the billed set is image/audio/video).
 */
export const MediaCostEstimateSchema = z
  .object({
    image: nonNegativeInt.optional(), // assumed images per media-output turn
    audio: nonNegativeInt.optional(), // assumed audio-seconds per media-output turn
    video: nonNegativeInt.optional(), // assumed video-seconds per media-output turn
  })
  .strict();
export type MediaCostEstimate = z.infer<typeof MediaCostEstimateSchema>;

/** `project.toml` / `workspace.toml` — project defaults, variables, project-scoped MCP, chat defaults. */
export const ProjectConfigSchema = z
  .object({
    defaults: z
      .object({
        model: z.string().optional(),
        fs_scope: FsScopeSchema.optional(),
        // Per-call output-token estimate the pre-egress budget governor uses when a node/session
        // omits maxTokens (ADR-0028) — not the model's absolute max, which would over-block.
        max_tokens_estimate: positiveInt.optional(),
        // Per-modality media-output unit-count default for the pre-egress media cost estimate (1.AF/D17).
        media_cost_estimate: MediaCostEstimateSchema.optional(),
        // Async media-job (generateMedia LRO) poll cadence + deadline (1.AG/ADR-0045 §7). The engine
        // polls at `poll_initial_ms`, exponential-backs-off (no jitter) capped at `poll_max_ms`, and
        // abandons a job past `deadline_ms` (from submit) as a retryable timeout. Defaults: 5s / 30s / 30min.
        media_job_poll_initial_ms: positiveInt.optional(),
        media_job_poll_max_ms: positiveInt.optional(),
        media_job_deadline_ms: positiveInt.optional(),
        // Grace window (in DAYS) before a zero-reference media handle's CAS bytes are reclaimed by the host
        // media GC (ADR-0042 §4c). Absent ⇒ the built-in 7-day default (DEFAULT_MEDIA_GC_GRACE_MS).
        media_gc_grace_days: positiveInt.optional(),
      })
      .strict()
      .refine(
        (d) =>
          d.media_job_poll_max_ms === undefined ||
          d.media_job_poll_initial_ms === undefined ||
          d.media_job_poll_max_ms >= d.media_job_poll_initial_ms,
        {
          message: 'media_job_poll_max_ms must be >= media_job_poll_initial_ms',
          path: ['media_job_poll_max_ms'],
        },
      )
      .optional(),
    variables: z.record(z.string(), z.string()).optional(),
    chat: ChatConfigSchema,
    // Project-scoped MCP registrations merge with the global ones (config-spec.md §resolution).
    mcp_servers: z.array(McpServerRegistrationSchema).optional(),
  })
  .strict();
export type ProjectConfig = z.infer<typeof ProjectConfigSchema>;
